// js/app.js
// Ties together Api and Player with the DOM: authentication flow, view
// rendering (Home/Search/Library/Favorites/Playlist/Album/Artist), the
// player bar, modals, and toast notifications.

(() => {
  const state = {
    user: null,
    playlists: [],
    favoriteIds: new Set(),
    view: 'home',
    viewParams: null,
    history: [], // simple back/forward stack of {view, params}
    historyPos: -1,
    songCache: new Map() // id -> song, used so player-bar clicks can look up metadata
  };

  const GRADIENTS = ['#33f5d0,#9b6bff', '#ff6fb5,#9b6bff', '#33f5d0,#0984e3', '#ffcb6e,#ff6fb5', '#9b6bff,#ff6fb5', '#33f5d0,#ffcb6e'];

  // ---------------------------------------------------------------------
  // Small utilities
  // ---------------------------------------------------------------------

  function el(html) {
    const t = document.createElement('template');
    t.innerHTML = html.trim();
    return t.content.firstElementChild;
  }

  function escapeHtml(str) {
    return String(str ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function formatDuration(seconds) {
    if (!seconds || !Number.isFinite(seconds)) return '0:00';
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return `${m}:${String(s).padStart(2, '0')}`;
  }

  function hashString(str) {
    let h = 0;
    for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
    return h;
  }

  /** Builds a small inline gradient-with-initial SVG data URI as a cover fallback. */
  function fallbackCover(label) {
    const pair = GRADIENTS[hashString(label || 'A') % GRADIENTS.length].split(',');
    const initial = (label || 'A').trim()[0]?.toUpperCase() || 'A';
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${pair[0]}"/><stop offset="1" stop-color="${pair[1]}"/></linearGradient></defs><rect width="100" height="100" fill="url(#g)"/><text x="50" y="62" font-family="sans-serif" font-size="40" font-weight="700" fill="rgba(255,255,255,0.9)" text-anchor="middle">${initial}</text></svg>`;
    return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
  }

  function coverFor(entity, fallbackLabel) {
    return entity && entity.coverUrl ? entity.coverUrl : fallbackCover(fallbackLabel);
  }

  function toast(message, type = 'info') {
    const stack = document.getElementById('toast-stack');
    const node = el(`<div class="toast ${type === 'error' ? 'error' : ''}">${escapeHtml(message)}</div>`);
    stack.appendChild(node);
    setTimeout(() => {
      node.style.transition = 'opacity 200ms ease';
      node.style.opacity = '0';
      setTimeout(() => node.remove(), 200);
    }, 3200);
  }

  function cacheSongs(songs) {
    songs.forEach((s) => state.songCache.set(s.id, s));
  }

  // ---------------------------------------------------------------------
  // Auth screen
  // ---------------------------------------------------------------------

  function showAuthScreen() {
    document.getElementById('auth-screen').classList.remove('hidden');
    document.getElementById('app').classList.add('hidden');
  }

  function showApp() {
    document.getElementById('auth-screen').classList.add('hidden');
    document.getElementById('app').classList.remove('hidden');
  }

  function wireAuthForms() {
    document.getElementById('show-register').addEventListener('click', () => {
      document.getElementById('login-panel').classList.add('hidden');
      document.getElementById('register-panel').classList.remove('hidden');
    });
    document.getElementById('show-login').addEventListener('click', () => {
      document.getElementById('register-panel').classList.add('hidden');
      document.getElementById('login-panel').classList.remove('hidden');
    });

    document.getElementById('login-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = document.getElementById('login-email').value.trim();
      const password = document.getElementById('login-password').value;
      const errorBox = document.getElementById('login-error');
      errorBox.textContent = '';
      try {
        const { user, token } = await Api.login({ email, password });
        Api.setSession(token, user);
        await bootAuthenticated();
      } catch (err) {
        errorBox.textContent = err.message;
      }
    });

    document.getElementById('register-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const username = document.getElementById('register-username').value.trim();
      const email = document.getElementById('register-email').value.trim();
      const password = document.getElementById('register-password').value;
      const errorBox = document.getElementById('register-error');
      errorBox.textContent = '';
      try {
        const { user, token } = await Api.register({ username, email, password });
        Api.setSession(token, user);
        await bootAuthenticated();
      } catch (err) {
        errorBox.textContent = err.details ? err.details.join(' ') : err.message;
      }
    });
  }

  function logout() {
    Api.clearSession();
    Player.pause();
    state.user = null;
    showAuthScreen();
  }

  // ---------------------------------------------------------------------
  // Sidebar / topbar chrome
  // ---------------------------------------------------------------------

  function renderUserChrome() {
    const initial = (state.user.username || '?')[0].toUpperCase();
    document.getElementById('sidebar-avatar').textContent = initial;
    document.getElementById('sidebar-username').textContent = state.user.username;
    document.getElementById('topbar-avatar').textContent = initial;
    document.getElementById('topbar-username').textContent = state.user.username;
    document.getElementById('admin-link').classList.toggle('hidden', state.user.role !== 'admin');
  }

  async function refreshSidebarPlaylists() {
    try {
      const { playlists } = await Api.listPlaylists();
      state.playlists = playlists;
      const container = document.getElementById('sidebar-playlists');
      container.innerHTML = playlists
        .map(
          (p) => `
        <button class="playlist-nav-item" data-playlist-id="${p.id}">
          <img class="swatch" src="${coverFor(p, p.name)}" alt="" />
          <span>${escapeHtml(p.name)}</span>
        </button>`
        )
        .join('');
      container.querySelectorAll('[data-playlist-id]').forEach((btn) => {
        btn.addEventListener('click', () => navigate('playlist', { id: Number(btn.dataset.playlistId) }));
      });
    } catch (err) {
      console.error(err);
    }
  }

  function setActiveNav(view) {
    document.querySelectorAll('.nav-item[data-view]').forEach((btn) => {
      btn.classList.toggle('active', btn.dataset.view === view);
    });
  }

  function wireSidebarNav() {
    document.querySelectorAll('.nav-item[data-view]').forEach((btn) => {
      btn.addEventListener('click', () => navigate(btn.dataset.view));
    });
    document.getElementById('sidebar-new-playlist').addEventListener('click', openCreatePlaylistModal);
    document.getElementById('user-chip').addEventListener('click', openAccountMenu);
    document.getElementById('user-chip-top').addEventListener('click', openAccountMenu);
    document.getElementById('btn-back').addEventListener('click', goBack);
    document.getElementById('btn-forward').addEventListener('click', goForward);
  }

  function openAccountMenu() {
    openModal(`
      <h3>Account</h3>
      <p style="color:var(--text-muted);font-size:0.88rem;margin-bottom:18px;">
        Signed in as <strong style="color:var(--text-primary)">${escapeHtml(state.user.username)}</strong> (${escapeHtml(state.user.email)})
      </p>
      <div class="modal-actions">
        <button class="btn btn-ghost" data-close>Close</button>
        <button class="btn btn-danger" id="logout-btn">Log out</button>
      </div>
    `);
    document.getElementById('logout-btn').addEventListener('click', () => {
      closeModal();
      logout();
    });
  }

  // ---------------------------------------------------------------------
  // Navigation (very small history stack so back/forward buttons work)
  // ---------------------------------------------------------------------

  function navigate(view, params = null, { record = true } = {}) {
    state.view = view;
    state.viewParams = params;
    setActiveNav(view);
    if (record) {
      state.history = state.history.slice(0, state.historyPos + 1);
      state.history.push({ view, params });
      state.historyPos = state.history.length - 1;
    }
    document.getElementById('content-scroll').scrollTop = 0;
    renderView();
  }

  function goBack() {
    if (state.historyPos > 0) {
      state.historyPos -= 1;
      const { view, params } = state.history[state.historyPos];
      navigate(view, params, { record: false });
    }
  }
  function goForward() {
    if (state.historyPos < state.history.length - 1) {
      state.historyPos += 1;
      const { view, params } = state.history[state.historyPos];
      navigate(view, params, { record: false });
    }
  }

  // ---------------------------------------------------------------------
  // Song row / card renderers (shared across views)
  // ---------------------------------------------------------------------

  function songRowHtml(song, index) {
    const isFav = state.favoriteIds.has(song.id);
    return `
    <div class="song-row" data-song-id="${song.id}">
      <div class="song-row-index">${index + 1}</div>
      <div class="song-row-main" data-role="play">
        <img class="song-row-art" src="${coverFor(song, song.title)}" alt="" />
        <div class="song-row-text">
          <div class="song-title">${escapeHtml(song.title)}</div>
          <div class="song-artist">${escapeHtml(song.Artist ? song.Artist.name : 'Unknown artist')}</div>
        </div>
      </div>
      <div class="song-row-album">${escapeHtml(song.Album ? song.Album.title : '—')}</div>
      <div class="song-row-duration">${formatDuration(song.duration)}</div>
      <div style="display:flex;align-items:center;gap:4px;">
        <button class="song-row-fav" data-role="add-playlist" title="Add to playlist">
          <svg class="icon" viewBox="0 0 24 24" style="width:16px;height:16px"><path d="M12 5v14M5 12h14"/></svg>
        </button>
        <button class="song-row-fav ${isFav ? 'active' : ''}" data-role="fav" title="Save to your favorites">
          <svg class="icon" viewBox="0 0 24 24" style="width:16px;height:16px"><path d="M12 20s-7-4.4-9.5-9A5.5 5.5 0 0 1 12 6a5.5 5.5 0 0 1 9.5 5c-2.5 4.6-9.5 9-9.5 9Z"/></svg>
        </button>
      </div>
    </div>`;
  }

  /**
   * Renders a list of songs into `container` and wires up:
   * - clicking a row to play the whole list starting at that song
   * - the heart icon to toggle favorites
   * `container` gets a data-song-list attribute so playlist "add" flows can read it.
   */
  function renderSongList(container, songs) {
    cacheSongs(songs);
    container.innerHTML = songs.length
      ? songs.map((s, i) => songRowHtml(s, i)).join('')
      : `<div class="empty-state"><h3>Nothing here yet</h3><p>Songs you add will show up in this list.</p></div>`;

    container.querySelectorAll('.song-row').forEach((row) => {
      const songId = Number(row.dataset.songId);
      row.querySelector('[data-role="play"]').addEventListener('click', () => {
        Player.loadQueue(songs, songs.findIndex((s) => s.id === songId));
      });
      row.querySelector('[data-role="fav"]').addEventListener('click', (e) => {
        e.stopPropagation();
        toggleFavorite(songId, row.querySelector('[data-role="fav"]'));
      });
      row.querySelector('[data-role="add-playlist"]').addEventListener('click', (e) => {
        e.stopPropagation();
        openAddToPlaylistModal(songId);
      });
    });
  }

  function cardHtml({ id, image, title, subtitle, type }) {
    return `
    <div class="card ${type === 'artist' ? 'artist' : ''}" data-entity-id="${id}" data-entity-type="${type}">
      <div class="card-art-wrap">
        <img class="card-art" src="${image}" alt="" />
        ${type === 'song' || type === 'album' ? `<button class="card-play-btn" data-role="quick-play"><svg class="icon" viewBox="0 0 24 24" style="stroke:none;fill:currentColor;width:16px;height:16px"><path d="M8 5v14l11-7Z"/></svg></button>` : ''}
      </div>
      <div class="card-title">${escapeHtml(title)}</div>
      <div class="card-subtitle">${escapeHtml(subtitle)}</div>
    </div>`;
  }

  async function toggleFavorite(songId, btnEl) {
    const isFav = state.favoriteIds.has(songId);
    try {
      if (isFav) {
        state.favoriteIds.delete(songId);
        await Api.removeFavorite(songId);
      } else {
        state.favoriteIds.add(songId);
        await Api.addFavorite(songId);
      }
      document.querySelectorAll(`[data-song-id="${songId}"] [data-role="fav"]`).forEach((b) => b.classList.toggle('active', state.favoriteIds.has(songId)));
      if (btnEl) btnEl.classList.toggle('active', state.favoriteIds.has(songId));
      syncNowPlayingFavIcon();
    } catch (err) {
      toast(err.message, 'error');
    }
  }

  // ---------------------------------------------------------------------
  // Views
  // ---------------------------------------------------------------------

  function skeletonCards(n = 6) {
    return `<div class="card-grid">${Array.from({ length: n }).map(() => '<div class="skeleton skeleton-card"></div>').join('')}</div>`;
  }
  function skeletonRows(n = 5) {
    return Array.from({ length: n }).map(() => '<div class="skeleton skeleton-row"></div>').join('');
  }

  const Views = {};

  Views.home = async (root) => {
    root.innerHTML = `
      <div class="view">
        <div class="section"><div class="section-head"><h2>Recently played</h2></div><div id="home-recent">${skeletonCards(5)}</div></div>
        <div class="section"><div class="section-head"><h2>Trending now</h2></div><div id="home-trending">${skeletonCards(6)}</div></div>
        <div class="section"><div class="section-head"><h2>Albums</h2></div><div id="home-albums">${skeletonCards(6)}</div></div>
        <div class="section"><div class="section-head"><h2>Artists</h2></div><div id="home-artists">${skeletonCards(6)}</div></div>
        <div class="section"><div class="section-head"><h2>Recommended for you</h2></div><div id="home-recommended">${skeletonCards(6)}</div></div>
      </div>`;

    const [recentRes, trendingRes, albumsRes, artistsRes, allSongsRes] = await Promise.allSettled([
      Api.getRecentlyPlayed(),
      Api.listSongs('?sort=trending&limit=10'),
      Api.listAlbums(),
      Api.listArtists(),
      Api.listSongs('?limit=20')
    ]);

    // Recently played
    const recentBox = document.getElementById('home-recent');
    if (recentRes.status === 'fulfilled' && recentRes.value.songs.length) {
      const songs = recentRes.value.songs;
      cacheSongs(songs);
      recentBox.innerHTML = `<div class="card-grid">${songs.map((s) => cardHtml({ id: s.id, image: coverFor(s, s.title), title: s.title, subtitle: s.Artist ? s.Artist.name : '', type: 'song' })).join('')}</div>`;
      wireSongCards(recentBox, songs);
    } else {
      recentBox.innerHTML = `<div class="empty-state" style="padding:24px;"><p>Play something and it will show up here.</p></div>`;
    }

    // Trending
    const trendingBox = document.getElementById('home-trending');
    if (trendingRes.status === 'fulfilled') {
      const songs = trendingRes.value.songs;
      cacheSongs(songs);
      trendingBox.innerHTML = `<div class="card-grid">${songs.map((s) => cardHtml({ id: s.id, image: coverFor(s, s.title), title: s.title, subtitle: s.Artist ? s.Artist.name : '', type: 'song' })).join('')}</div>`;
      wireSongCards(trendingBox, songs);
    }

    // Albums
    const albumsBox = document.getElementById('home-albums');
    if (albumsRes.status === 'fulfilled') {
      const albums = albumsRes.value.albums;
      albumsBox.innerHTML = `<div class="card-grid">${albums.map((a) => cardHtml({ id: a.id, image: coverFor(a, a.title), title: a.title, subtitle: a.Artist ? a.Artist.name : '', type: 'album' })).join('')}</div>`;
      wireEntityCards(albumsBox, 'album');
    }

    // Artists
    const artistsBox = document.getElementById('home-artists');
    if (artistsRes.status === 'fulfilled') {
      const artists = artistsRes.value.artists;
      artistsBox.innerHTML = `<div class="card-grid">${artists.map((a) => cardHtml({ id: a.id, image: coverFor(a, a.name), title: a.name, subtitle: a.genre || 'Artist', type: 'artist' })).join('')}</div>`;
      wireEntityCards(artistsBox, 'artist');
    }

    // Recommended (simple heuristic: shuffled slice of the catalog, distinct from trending order)
    const recBox = document.getElementById('home-recommended');
    if (allSongsRes.status === 'fulfilled') {
      const songs = allSongsRes.value.songs.slice().sort(() => Math.random() - 0.5).slice(0, 10);
      cacheSongs(songs);
      recBox.innerHTML = `<div class="card-grid">${songs.map((s) => cardHtml({ id: s.id, image: coverFor(s, s.title), title: s.title, subtitle: s.Artist ? s.Artist.name : '', type: 'song' })).join('')}</div>`;
      wireSongCards(recBox, songs);
    }
  };

  function wireSongCards(container, songs) {
    container.querySelectorAll('.card[data-entity-type="song"]').forEach((card) => {
      const id = Number(card.dataset.entityId);
      card.addEventListener('click', () => Player.loadQueue(songs, songs.findIndex((s) => s.id === id)));
    });
  }

  function wireEntityCards(container, type) {
    container.querySelectorAll(`.card[data-entity-type="${type}"]`).forEach((card) => {
      const id = Number(card.dataset.entityId);
      card.addEventListener('click', () => navigate(type, { id }));
      if (type === 'album') {
        const playBtn = card.querySelector('[data-role="quick-play"]');
        if (playBtn) {
          playBtn.addEventListener('click', async (e) => {
            e.stopPropagation();
            const { album } = await Api.getAlbum(id);
            if (album.Songs && album.Songs.length) Player.loadQueue(album.Songs, 0);
          });
        }
      }
    });
  }

  let searchDebounce = null;
  Views.search = async (root) => {
    const q = (state.viewParams && state.viewParams.q) || '';
    root.innerHTML = `
      <div class="view">
        <div class="section">
          <div class="search-bar" style="max-width:520px;margin-bottom:24px;">
            <svg class="icon" viewBox="0 0 24 24" style="width:16px;height:16px"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
            <input type="text" id="page-search-input" placeholder="Search songs, artists, albums..." value="${escapeHtml(q)}" />
          </div>
          <div id="search-results"></div>
        </div>
      </div>`;

    const input = document.getElementById('page-search-input');
    input.focus();
    input.setSelectionRange(input.value.length, input.value.length);

    const runSearch = async (query) => {
      const box = document.getElementById('search-results');
      if (!query.trim()) {
        box.innerHTML = `<div class="empty-state"><h3>Search your library</h3><p>Find songs, artists, and albums.</p></div>`;
        return;
      }
      box.innerHTML = skeletonRows(6);
      const results = await Api.globalSearch(query);
      renderSearchResults(box, results);
    };

    input.addEventListener('input', () => {
      clearTimeout(searchDebounce);
      const query = input.value;
      searchDebounce = setTimeout(() => runSearch(query), 300);
    });

    await runSearch(q);
  };

  function renderSearchResults(box, { songs, artists, albums }) {
    if (!songs.length && !artists.length && !albums.length) {
      box.innerHTML = `<div class="empty-state"><h3>No results</h3><p>Try a different search term.</p></div>`;
      return;
    }
    box.innerHTML = `
      ${artists.length ? `<div class="section"><div class="section-head"><h2>Artists</h2></div><div class="card-grid">${artists.map((a) => cardHtml({ id: a.id, image: coverFor(a, a.name), title: a.name, subtitle: 'Artist', type: 'artist' })).join('')}</div></div>` : ''}
      ${albums.length ? `<div class="section"><div class="section-head"><h2>Albums</h2></div><div class="card-grid">${albums.map((a) => cardHtml({ id: a.id, image: coverFor(a, a.title), title: a.title, subtitle: a.Artist ? a.Artist.name : '', type: 'album' })).join('')}</div></div>` : ''}
      ${songs.length ? `<div class="section"><div class="section-head"><h2>Songs</h2></div><div id="search-song-rows"></div></div>` : ''}
    `;
    if (artists.length) wireEntityCards(box, 'artist');
    if (albums.length) wireEntityCards(box, 'album');
    if (songs.length) renderSongList(document.getElementById('search-song-rows'), songs);
  }

  let libraryPage = 1;
  let libraryLoading = false;
  let libraryDone = false;
  Views.library = async (root) => {
    libraryPage = 1;
    libraryDone = false;
    root.innerHTML = `
      <div class="view">
        <div class="section-head"><h2>Your library</h2></div>
        <div id="library-rows"></div>
        <div id="library-sentinel" style="height:1px;"></div>
      </div>`;
    await loadMoreLibrary();

    // Infinite scroll: watch the scroll container and load more near the bottom.
    const scrollBox = document.getElementById('content-scroll');
    const onScroll = () => {
      if (state.view !== 'library') {
        scrollBox.removeEventListener('scroll', onScroll);
        return;
      }
      if (libraryLoading || libraryDone) return;
      if (scrollBox.scrollTop + scrollBox.clientHeight > scrollBox.scrollHeight - 300) {
        loadMoreLibrary();
      }
    };
    scrollBox.addEventListener('scroll', onScroll);
  };

  async function loadMoreLibrary() {
    if (libraryLoading || libraryDone) return;
    libraryLoading = true;
    const rowsBox = document.getElementById('library-rows');
    const loadingIndicator = el(`<div class="library-loading">${skeletonRows(3)}</div>`);
    rowsBox.appendChild(loadingIndicator);

    try {
      const { songs, pages } = await Api.listSongs(`?page=${libraryPage}&limit=20`);
      loadingIndicator.remove();
      cacheSongs(songs);
      const startIdx = rowsBox.querySelectorAll('.song-row').length;
      songs.forEach((s, i) => rowsBox.insertAdjacentHTML('beforeend', songRowHtml(s, startIdx + i)));

      // Wire the newly added rows. The "queue" for library playback is the
      // full set of songs loaded so far, so next/prev flow through pages.
      const allLoadedSongs = songs; // wiring uses closures per batch is fine since ids are unique
      rowsBox.querySelectorAll('.song-row').forEach((row) => {
        if (row.dataset.wired) return;
        row.dataset.wired = '1';
        const songId = Number(row.dataset.songId);
        row.querySelector('[data-role="play"]').addEventListener('click', () => {
          const allSongs = [...rowsBox.querySelectorAll('.song-row')].map((r) => state.songCache.get(Number(r.dataset.songId))).filter(Boolean);
          Player.loadQueue(allSongs, allSongs.findIndex((s) => s.id === songId));
        });
        row.querySelector('[data-role="fav"]').addEventListener('click', (e) => {
          e.stopPropagation();
          toggleFavorite(songId, row.querySelector('[data-role="fav"]'));
        });
        row.querySelector('[data-role="add-playlist"]').addEventListener('click', (e) => {
          e.stopPropagation();
          openAddToPlaylistModal(songId);
        });
      });

      libraryPage += 1;
      if (libraryPage > pages) libraryDone = true;
    } catch (err) {
      loadingIndicator.remove();
      toast('Could not load more songs.', 'error');
    } finally {
      libraryLoading = false;
    }
  }

  Views.favorites = async (root) => {
    root.innerHTML = `
      <div class="view">
        <div class="detail-header">
          <div class="detail-cover" style="background:var(--aurora-gradient);display:flex;align-items:center;justify-content:center;">
            <svg class="icon" viewBox="0 0 24 24" style="width:64px;height:64px;stroke:none;fill:#05070f"><path d="M12 20s-7-4.4-9.5-9A5.5 5.5 0 0 1 12 6a5.5 5.5 0 0 1 9.5 5c-2.5 4.6-9.5 9-9.5 9Z"/></svg>
          </div>
          <div>
            <div class="detail-kicker">Playlist</div>
            <h1 class="detail-title">Favorites</h1>
            <div class="detail-meta" id="fav-count">Loading…</div>
          </div>
        </div>
        <div id="fav-rows">${skeletonRows(5)}</div>
      </div>`;

    const { songs } = await Api.listFavorites();
    document.getElementById('fav-count').textContent = `${songs.length} liked song${songs.length === 1 ? '' : 's'}`;
    renderSongList(document.getElementById('fav-rows'), songs);
  };

  Views.playlist = async (root) => {
    const id = state.viewParams.id;
    root.innerHTML = `<div class="view">${skeletonCards(1)}${skeletonRows(5)}</div>`;
    let playlist;
    try {
      ({ playlist } = await Api.getPlaylist(id));
    } catch (err) {
      root.innerHTML = `<div class="empty-state"><h3>Playlist unavailable</h3><p>${escapeHtml(err.message)}</p></div>`;
      return;
    }

    const isOwner = state.user && playlist.ownerId === state.user.id;
    root.innerHTML = `
      <div class="view">
        <div class="detail-header">
          <img class="detail-cover" src="${coverFor(playlist, playlist.name)}" alt="" />
          <div>
            <div class="detail-kicker">${playlist.isPublic ? 'Public playlist' : 'Private playlist'}</div>
            <h1 class="detail-title">${escapeHtml(playlist.name)}</h1>
            <div class="detail-meta">${escapeHtml(playlist.description || '')} ${playlist.description ? '· ' : ''}${playlist.songs.length} songs · by ${escapeHtml(playlist.owner ? playlist.owner.username : 'Unknown')}</div>
          </div>
        </div>
        <div class="detail-actions">
          <button class="icon-btn-lg" id="playlist-play-all" title="Play"><svg class="icon" viewBox="0 0 24 24" style="stroke:none;fill:currentColor;width:22px;height:22px"><path d="M8 5v14l11-7Z"/></svg></button>
          ${isOwner ? `<button class="icon-btn-outline" id="playlist-edit" title="Edit details"><svg class="icon" viewBox="0 0 24 24" style="width:18px;height:18px"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg></button>
          <button class="icon-btn-outline" id="playlist-delete" title="Delete playlist"><svg class="icon" viewBox="0 0 24 24" style="width:18px;height:18px"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/></svg></button>` : ''}
        </div>
        <div id="playlist-rows"></div>
      </div>`;

    renderPlaylistSongRows(document.getElementById('playlist-rows'), playlist, isOwner);

    document.getElementById('playlist-play-all').addEventListener('click', () => {
      if (playlist.songs.length) Player.loadQueue(playlist.songs, 0);
    });
    if (isOwner) {
      document.getElementById('playlist-edit').addEventListener('click', () => openEditPlaylistModal(playlist));
      document.getElementById('playlist-delete').addEventListener('click', () => confirmDeletePlaylist(playlist));
    }
  };

  function renderPlaylistSongRows(container, playlist, isOwner) {
    cacheSongs(playlist.songs);
    container.innerHTML = playlist.songs.length
      ? playlist.songs.map((s, i) => songRowHtml(s, i)).join('')
      : `<div class="empty-state"><h3>This playlist is empty</h3><p>Add songs from Search or your Library.</p></div>`;

    container.querySelectorAll('.song-row').forEach((row) => {
      const songId = Number(row.dataset.songId);
      row.querySelector('[data-role="play"]').addEventListener('click', () => {
        Player.loadQueue(playlist.songs, playlist.songs.findIndex((s) => s.id === songId));
      });
      row.querySelector('[data-role="fav"]').addEventListener('click', (e) => {
        e.stopPropagation();
        toggleFavorite(songId, row.querySelector('[data-role="fav"]'));
      });
      row.querySelector('[data-role="add-playlist"]').addEventListener('click', (e) => {
        e.stopPropagation();
        openAddToPlaylistModal(songId);
      });
      if (isOwner) {
        const removeBtn = el(`<button class="song-row-fav" title="Remove from playlist" style="margin-left:4px;"><svg class="icon" viewBox="0 0 24 24" style="width:16px;height:16px"><path d="M18 6 6 18"/><path d="M6 6l12 12"/></svg></button>`);
        row.appendChild(removeBtn);
        removeBtn.addEventListener('click', async (e) => {
          e.stopPropagation();
          try {
            await Api.removeSongFromPlaylist(playlist.id, songId);
            playlist.songs = playlist.songs.filter((s) => s.id !== songId);
            renderPlaylistSongRows(container, playlist, isOwner);
            toast('Removed from playlist.');
          } catch (err) {
            toast(err.message, 'error');
          }
        });
      }
    });
  }

  Views.album = async (root) => {
    const id = state.viewParams.id;
    root.innerHTML = `<div class="view">${skeletonCards(1)}${skeletonRows(5)}</div>`;
    const { album } = await Api.getAlbum(id);
    root.innerHTML = `
      <div class="view">
        <div class="detail-header">
          <img class="detail-cover" src="${coverFor(album, album.title)}" alt="" />
          <div>
            <div class="detail-kicker">Album</div>
            <h1 class="detail-title">${escapeHtml(album.title)}</h1>
            <div class="detail-meta">${escapeHtml(album.Artist ? album.Artist.name : '')} ${album.releaseYear ? `· ${album.releaseYear}` : ''} · ${album.Songs.length} songs</div>
          </div>
        </div>
        <div class="detail-actions">
          <button class="icon-btn-lg" id="album-play-all"><svg class="icon" viewBox="0 0 24 24" style="stroke:none;fill:currentColor;width:22px;height:22px"><path d="M8 5v14l11-7Z"/></svg></button>
        </div>
        <div id="album-rows"></div>
      </div>`;
    renderSongList(document.getElementById('album-rows'), album.Songs);
    document.getElementById('album-play-all').addEventListener('click', () => {
      if (album.Songs.length) Player.loadQueue(album.Songs, 0);
    });
  };

  Views.artist = async (root) => {
    const id = state.viewParams.id;
    root.innerHTML = `<div class="view">${skeletonCards(1)}${skeletonRows(5)}</div>`;
    const { artist } = await Api.getArtist(id);
    root.innerHTML = `
      <div class="view">
        <div class="detail-header">
          <img class="detail-cover round" src="${coverFor(artist, artist.name)}" alt="" />
          <div>
            <div class="detail-kicker">Artist</div>
            <h1 class="detail-title">${escapeHtml(artist.name)}</h1>
            <div class="detail-meta">${escapeHtml(artist.genre || '')}</div>
          </div>
        </div>
        ${artist.bio ? `<p style="color:var(--text-muted);max-width:640px;margin-bottom:22px;">${escapeHtml(artist.bio)}</p>` : ''}
        <div class="detail-actions">
          <button class="icon-btn-lg" id="artist-play-all"><svg class="icon" viewBox="0 0 24 24" style="stroke:none;fill:currentColor;width:22px;height:22px"><path d="M8 5v14l11-7Z"/></svg></button>
        </div>
        <div class="section-head"><h2>Popular songs</h2></div>
        <div id="artist-rows"></div>
        ${artist.Albums && artist.Albums.length ? `<div class="section" style="margin-top:30px;"><div class="section-head"><h2>Albums</h2></div><div class="card-grid" id="artist-albums"></div></div>` : ''}
      </div>`;

    const songs = artist.Songs || [];
    renderSongList(document.getElementById('artist-rows'), songs);
    document.getElementById('artist-play-all').addEventListener('click', () => {
      if (songs.length) Player.loadQueue(songs, 0);
    });

    if (artist.Albums && artist.Albums.length) {
      const box = document.getElementById('artist-albums');
      box.innerHTML = artist.Albums.map((a) => cardHtml({ id: a.id, image: coverFor(a, a.title), title: a.title, subtitle: artist.name, type: 'album' })).join('');
      wireEntityCards(box, 'album');
    }
  };

  async function renderView() {
    const root = document.getElementById('view-root');
    try {
      await Views[state.view](root);
    } catch (err) {
      console.error(err);
      root.innerHTML = `<div class="empty-state"><h3>Something went wrong</h3><p>${escapeHtml(err.message)}</p></div>`;
    }
  }

  // ---------------------------------------------------------------------
  // Modals
  // ---------------------------------------------------------------------

  function openModal(innerHtml) {
    closeModal();
    const overlay = el(`<div class="modal-overlay"><div class="modal">${innerHtml}<button class="modal-close" data-close aria-label="Close">✕</button></div></div>`);
    document.getElementById('modal-root').appendChild(overlay);
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay || e.target.hasAttribute('data-close')) closeModal();
    });
    return overlay;
  }
  function closeModal() {
    document.getElementById('modal-root').innerHTML = '';
  }

  function openCreatePlaylistModal() {
    const overlay = openModal(`
      <h3>Create playlist</h3>
      <form id="create-playlist-form">
        <div class="field"><label>Name</label><input type="text" id="new-playlist-name" required maxlength="60" /></div>
        <div class="field"><label>Description (optional)</label><textarea id="new-playlist-desc" maxlength="200"></textarea></div>
        <div class="field-checkbox"><input type="checkbox" id="new-playlist-public" checked /><label for="new-playlist-public">Public — anyone can view this playlist</label></div>
        <div class="field-error" id="create-playlist-error"></div>
        <div class="modal-actions">
          <button type="button" class="btn btn-ghost" data-close>Cancel</button>
          <button type="submit" class="btn btn-gradient">Create</button>
        </div>
      </form>
    `);
    overlay.querySelector('#create-playlist-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const name = document.getElementById('new-playlist-name').value.trim();
      const description = document.getElementById('new-playlist-desc').value.trim();
      const isPublic = document.getElementById('new-playlist-public').checked;
      try {
        const { playlist } = await Api.createPlaylist({ name, description, isPublic });
        closeModal();
        await refreshSidebarPlaylists();
        toast('Playlist created.');
        navigate('playlist', { id: playlist.id });
      } catch (err) {
        document.getElementById('create-playlist-error').textContent = err.message;
      }
    });
  }

  function openEditPlaylistModal(playlist) {
    const overlay = openModal(`
      <h3>Edit playlist</h3>
      <form id="edit-playlist-form">
        <div class="field"><label>Name</label><input type="text" id="edit-playlist-name" value="${escapeHtml(playlist.name)}" required maxlength="60" /></div>
        <div class="field"><label>Description</label><textarea id="edit-playlist-desc" maxlength="200">${escapeHtml(playlist.description || '')}</textarea></div>
        <div class="field-checkbox"><input type="checkbox" id="edit-playlist-public" ${playlist.isPublic ? 'checked' : ''} /><label for="edit-playlist-public">Public</label></div>
        <div class="field-error" id="edit-playlist-error"></div>
        <div class="modal-actions">
          <button type="button" class="btn btn-ghost" data-close>Cancel</button>
          <button type="submit" class="btn btn-gradient">Save</button>
        </div>
      </form>
    `);
    overlay.querySelector('#edit-playlist-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      try {
        await Api.updatePlaylist(playlist.id, {
          name: document.getElementById('edit-playlist-name').value.trim(),
          description: document.getElementById('edit-playlist-desc').value.trim(),
          isPublic: document.getElementById('edit-playlist-public').checked
        });
        closeModal();
        await refreshSidebarPlaylists();
        navigate('playlist', { id: playlist.id }, { record: false });
        toast('Playlist updated.');
      } catch (err) {
        document.getElementById('edit-playlist-error').textContent = err.message;
      }
    });
  }

  function confirmDeletePlaylist(playlist) {
    openModal(`
      <h3>Delete "${escapeHtml(playlist.name)}"?</h3>
      <p style="color:var(--text-muted);font-size:0.88rem;">This can't be undone.</p>
      <div class="modal-actions">
        <button class="btn btn-ghost" data-close>Cancel</button>
        <button class="btn btn-danger" id="confirm-delete-playlist">Delete</button>
      </div>
    `);
    document.getElementById('confirm-delete-playlist').addEventListener('click', async () => {
      try {
        await Api.deletePlaylist(playlist.id);
        closeModal();
        await refreshSidebarPlaylists();
        navigate('home');
        toast('Playlist deleted.');
      } catch (err) {
        toast(err.message, 'error');
      }
    });
  }

  function openAddToPlaylistModal(songId) {
    if (!state.playlists.length) {
      toast('Create a playlist first.');
      return;
    }
    const own = state.playlists.filter((p) => !state.user || p.ownerId === state.user.id || p.owner?.id === state.user.id);
    openModal(`
      <h3>Add to playlist</h3>
      <div>
        ${own
          .map(
            (p) => `
          <div class="playlist-picker-item">
            <img class="swatch" style="width:26px;height:26px;border-radius:6px;" src="${coverFor(p, p.name)}" alt="" />
            <span style="flex:1;">${escapeHtml(p.name)}</span>
            <button class="btn btn-sm btn-ghost" data-add-to="${p.id}">Add</button>
          </div>`
          )
          .join('')}
      </div>
      <div class="modal-actions"><button class="btn btn-ghost" data-close>Done</button></div>
    `).querySelectorAll('[data-add-to]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        try {
          await Api.addSongToPlaylist(Number(btn.dataset.addTo), songId);
          toast('Added to playlist.');
        } catch (err) {
          toast(err.message, 'error');
        }
      });
    });
  }

  // ---------------------------------------------------------------------
  // Player bar wiring
  // ---------------------------------------------------------------------

  function syncNowPlayingFavIcon() {
    const song = Player.currentSong();
    const favBtn = document.getElementById('now-playing-fav');
    if (!song) return;
    favBtn.classList.toggle('active', state.favoriteIds.has(song.id));
  }

  function wirePlayerBar() {
    const playBtn = document.getElementById('btn-play');
    const iconPlay = document.getElementById('icon-play');
    const iconPause = document.getElementById('icon-pause');
    const seekSlider = document.getElementById('seek-slider');
    const volumeSlider = document.getElementById('volume-slider');
    const timeCurrent = document.getElementById('time-current');
    const timeDuration = document.getElementById('time-duration');

    playBtn.addEventListener('click', () => Player.togglePlay());
    document.getElementById('btn-next').addEventListener('click', () => Player.next());
    document.getElementById('btn-prev').addEventListener('click', () => Player.prev());

    const shuffleBtn = document.getElementById('btn-shuffle');
    shuffleBtn.addEventListener('click', () => {
      Player.setShuffle(!Player.isShuffled);
      shuffleBtn.classList.toggle('active', Player.isShuffled);
    });

    const repeatBtn = document.getElementById('btn-repeat');
    repeatBtn.addEventListener('click', () => {
      const mode = Player.cycleRepeat();
      repeatBtn.classList.toggle('active', mode !== 'off');
      document.getElementById('repeat-one-dot').classList.toggle('hidden', mode !== 'one');
    });

    let seeking = false;
    seekSlider.addEventListener('input', () => {
      seeking = true;
      seekSlider.style.setProperty('--_pct', `${seekSlider.value}%`);
    });
    seekSlider.addEventListener('change', () => {
      const duration = Player.audioEl.duration || 0;
      Player.seekTo((seekSlider.value / 100) * duration);
      seeking = false;
    });

    volumeSlider.addEventListener('input', () => {
      Player.setVolume(volumeSlider.value / 100);
      volumeSlider.style.setProperty('--_pct', `${volumeSlider.value}%`);
      updateMuteIcon();
    });
    Player.setVolume(0.8);

    const muteBtn = document.getElementById('btn-mute');
    function updateMuteIcon() {
      const muted = Player.audioEl.muted || Player.audioEl.volume === 0;
      document.getElementById('icon-vol').classList.toggle('hidden', muted);
      document.getElementById('icon-mute').classList.toggle('hidden', !muted);
    }
    muteBtn.addEventListener('click', () => {
      Player.toggleMute();
      updateMuteIcon();
    });

    const speeds = [1, 1.25, 1.5, 1.75, 2, 0.75];
    let speedIdx = 0;
    document.getElementById('btn-speed').addEventListener('click', (e) => {
      speedIdx = (speedIdx + 1) % speeds.length;
      Player.setSpeed(speeds[speedIdx]);
      e.target.textContent = `${speeds[speedIdx]}x`;
    });

    document.getElementById('now-playing-fav').addEventListener('click', () => {
      const song = Player.currentSong();
      if (song) toggleFavorite(song.id, document.getElementById('now-playing-fav'));
    });

    Player.on('trackchange', (song) => {
      document.getElementById('now-playing-art').src = coverFor(song, song.title);
      document.getElementById('now-playing-title').textContent = song.title;
      document.getElementById('now-playing-artist').textContent = song.Artist ? song.Artist.name : 'Unknown artist';
      syncNowPlayingFavIcon();
    });

    Player.on('play', () => {
      iconPlay.classList.add('hidden');
      iconPause.classList.remove('hidden');
    });
    Player.on('pause', () => {
      iconPlay.classList.remove('hidden');
      iconPause.classList.add('hidden');
    });

    Player.on('timeupdate', ({ currentTime, duration }) => {
      if (!seeking && Number.isFinite(duration) && duration > 0) {
        const pct = (currentTime / duration) * 100;
        seekSlider.value = pct;
        seekSlider.style.setProperty('--_pct', `${pct}%`);
      }
      timeCurrent.textContent = formatDuration(currentTime);
      timeDuration.textContent = formatDuration(duration);
    });
  }

  // ---------------------------------------------------------------------
  // Audio-reactive visualizer (signature element)
  // ---------------------------------------------------------------------

  function startVisualizer() {
    const canvas = document.getElementById('visualizer');
    const ctx = canvas.getContext('2d');

    function resize() {
      canvas.width = canvas.clientWidth * devicePixelRatio;
      canvas.height = canvas.clientHeight * devicePixelRatio;
    }
    window.addEventListener('resize', resize);
    resize();

    const colors = ['#33f5d0', '#9b6bff', '#ff6fb5'];

    function draw() {
      requestAnimationFrame(draw);
      const analyser = Player.getAnalyser();
      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, w, h);

      if (!analyser || Player.audioEl.paused) return;

      const bufferLength = analyser.frequencyBinCount;
      const data = new Uint8Array(bufferLength);
      analyser.getByteFrequencyData(data);

      const barWidth = w / bufferLength;
      for (let i = 0; i < bufferLength; i++) {
        const barHeight = (data[i] / 255) * h * 0.9;
        ctx.fillStyle = colors[i % colors.length];
        ctx.fillRect(i * barWidth, h - barHeight, barWidth * 0.7, barHeight);
      }
    }
    draw();
  }

  // ---------------------------------------------------------------------
  // Global search bar (topbar) -> navigates to the Search view
  // ---------------------------------------------------------------------

  function wireTopSearch() {
    const input = document.getElementById('global-search-input');
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && input.value.trim()) {
        navigate('search', { q: input.value.trim() });
      }
    });
  }

  // ---------------------------------------------------------------------
  // Boot sequence
  // ---------------------------------------------------------------------

  async function bootAuthenticated() {
    try {
      const { user } = await Api.me();
      state.user = user;
    } catch {
      Api.clearSession();
      showAuthScreen();
      return;
    }
    showApp();
    renderUserChrome();

    try {
      const { songs } = await Api.listFavorites();
      state.favoriteIds = new Set(songs.map((s) => s.id));
    } catch {
      state.favoriteIds = new Set();
    }

    await refreshSidebarPlaylists();
    navigate('home');
  }

  document.addEventListener('DOMContentLoaded', () => {
    wireAuthForms();
    wireSidebarNav();
    wirePlayerBar();
    wireTopSearch();
    startVisualizer();

    if (Api.getToken()) {
      bootAuthenticated();
    } else {
      showAuthScreen();
    }
  });

  // Exposed for the add-to-playlist "+" affordance triggered elsewhere if needed.
  window.Auralis = { openAddToPlaylistModal, toast, navigate };
})();
