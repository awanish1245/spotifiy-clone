// js/admin.js
// Admin dashboard: gated by role, tabbed layout, CRUD forms for songs,
// albums, artists, playlists, and users.

(() => {
  let currentTab = 'overview';
  let cache = { artists: [], albums: [], songs: [] };

  function el(html) {
    const t = document.createElement('template');
    t.innerHTML = html.trim();
    return t.content.firstElementChild;
  }
  function escapeHtml(str) {
    return String(str ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }
  function toast(message, type = 'info') {
    const stack = document.getElementById('toast-stack');
    const node = el(`<div class="toast ${type === 'error' ? 'error' : ''}">${escapeHtml(message)}</div>`);
    stack.appendChild(node);
    setTimeout(() => {
      node.style.transition = 'opacity 200ms ease';
      node.style.opacity = '0';
      setTimeout(() => node.remove(), 200);
    }, 3200);
  }
  function fallbackCover(label) {
    const initial = (label || 'A').trim()[0]?.toUpperCase() || 'A';
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect width="100" height="100" fill="#242a49"/><text x="50" y="62" font-family="sans-serif" font-size="40" font-weight="700" fill="#9497b3" text-anchor="middle">${initial}</text></svg>`;
    return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
  }
  function cover(entity, label) {
    return entity && entity.coverUrl ? entity.coverUrl : entity && entity.imageUrl ? entity.imageUrl : fallbackCover(label);
  }

  function openModal(innerHtml) {
    closeModal();
    const overlay = el(`<div class="modal-overlay"><div class="modal">${innerHtml}<button class="modal-close" data-close aria-label="Close">✕</button></div></div>`);
    document.getElementById('modal-root').appendChild(overlay);
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay || e.target.hasAttribute('data-close')) closeModal();
    });
    return overlay;
  }
  function closeModal() {
    document.getElementById('modal-root').innerHTML = '';
  }

  // ---------------------------------------------------------------------
  // Overview
  // ---------------------------------------------------------------------

  async function renderOverview(root) {
    root.innerHTML = `<div class="admin-header"><h1>Overview</h1></div><div class="stat-grid" id="stat-grid"><div class="skeleton skeleton-card"></div><div class="skeleton skeleton-card"></div><div class="skeleton skeleton-card"></div></div>`;
    const stats = await Api.adminStats();
    document.getElementById('stat-grid').innerHTML = `
      <div class="stat-card"><div class="stat-value">${stats.users}</div><div class="stat-label">Registered users</div></div>
      <div class="stat-card"><div class="stat-value">${stats.songs}</div><div class="stat-label">Songs in library</div></div>
      <div class="stat-card"><div class="stat-value">${stats.playlists}</div><div class="stat-label">Playlists created</div></div>
    `;
  }

  // ---------------------------------------------------------------------
  // Songs
  // ---------------------------------------------------------------------

  async function renderSongs(root) {
    root.innerHTML = `
      <div class="admin-header"><h1>Songs</h1><button class="btn btn-gradient" id="upload-song-btn">Upload song</button></div>
      <div id="songs-table"><div class="skeleton skeleton-row"></div><div class="skeleton skeleton-row"></div></div>
    `;
    document.getElementById('upload-song-btn').addEventListener('click', openUploadSongModal);
    await loadSongsTable();
  }

  async function loadSongsTable() {
    const { songs } = await Api.listSongs('?limit=100');
    cache.songs = songs;
    const box = document.getElementById('songs-table');
    if (!songs.length) {
      box.innerHTML = `<div class="empty-state"><h3>No songs yet</h3><p>Upload your first track to get started.</p></div>`;
      return;
    }
    box.innerHTML = `
      <table class="admin-table">
        <thead><tr><th>Title</th><th>Artist</th><th>Album</th><th>Plays</th><th></th></tr></thead>
        <tbody>
          ${songs
            .map(
              (s) => `
            <tr data-song-id="${s.id}">
              <td><img class="thumb" src="${cover(s, s.title)}" alt="" />${escapeHtml(s.title)}</td>
              <td>${escapeHtml(s.Artist ? s.Artist.name : '—')}</td>
              <td>${escapeHtml(s.Album ? s.Album.title : '—')}</td>
              <td>${s.playCount}</td>
              <td class="row-actions">
                <button class="btn btn-sm btn-ghost" data-edit-song>Edit</button>
                <button class="btn btn-sm btn-danger" data-delete-song>Delete</button>
              </td>
            </tr>`
            )
            .join('')}
        </tbody>
      </table>`;

    box.querySelectorAll('[data-edit-song]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const id = Number(btn.closest('tr').dataset.songId);
        openEditSongModal(songs.find((s) => s.id === id));
      });
    });
    box.querySelectorAll('[data-delete-song]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const id = Number(btn.closest('tr').dataset.songId);
        if (!confirm('Delete this song? This cannot be undone.')) return;
        try {
          await Api.deleteSong(id);
          toast('Song deleted.');
          loadSongsTable();
        } catch (err) {
          toast(err.message, 'error');
        }
      });
    });
  }

  async function ensureArtistsAlbumsLoaded() {
    if (!cache.artists.length) cache.artists = (await Api.listArtists()).artists;
    if (!cache.albums.length) cache.albums = (await Api.listAlbums()).albums;
  }

  async function openUploadSongModal() {
    await ensureArtistsAlbumsLoaded();
    const overlay = openModal(`
      <h3>Upload a song</h3>
      <form id="upload-song-form">
        <div class="field"><label>Title</label><input type="text" id="song-title" required maxlength="120" /></div>
        <div class="field"><label>Artist</label>
          <select id="song-artist" required>
            <option value="">Select an artist…</option>
            ${cache.artists.map((a) => `<option value="${a.id}">${escapeHtml(a.name)}</option>`).join('')}
          </select>
        </div>
        <div class="field"><label>Album (optional)</label>
          <select id="song-album">
            <option value="">No album</option>
            ${cache.albums.map((a) => `<option value="${a.id}">${escapeHtml(a.title)}</option>`).join('')}
          </select>
        </div>
        <div class="field"><label>Genre</label><input type="text" id="song-genre" maxlength="40" /></div>
        <div class="field"><label>Track number</label><input type="number" id="song-track" min="1" value="1" /></div>
        <div class="field">
          <label>Audio file (MP3 / WAV / OGG, required)</label>
          <label class="upload-dropzone" id="audio-dropzone">
            Click to choose an audio file
            <input type="file" id="song-audio-file" accept="audio/mpeg,audio/mp3,audio/wav,audio/ogg" required />
            <div class="upload-file-name" id="audio-file-name"></div>
          </label>
        </div>
        <div class="field">
          <label>Cover image (optional — falls back to album cover)</label>
          <label class="upload-dropzone" id="cover-dropzone">
            Click to choose a cover image
            <input type="file" id="song-cover-file" accept="image/jpeg,image/png,image/webp" />
            <div class="upload-file-name" id="cover-file-name"></div>
          </label>
        </div>
        <div class="field-error" id="upload-song-error"></div>
        <div class="modal-actions">
          <button type="button" class="btn btn-ghost" data-close>Cancel</button>
          <button type="submit" class="btn btn-gradient" id="upload-submit-btn">Upload</button>
        </div>
      </form>
    `);

    overlay.querySelector('#song-audio-file').addEventListener('change', (e) => {
      document.getElementById('audio-file-name').textContent = e.target.files[0]?.name || '';
    });
    overlay.querySelector('#song-cover-file').addEventListener('change', (e) => {
      document.getElementById('cover-file-name').textContent = e.target.files[0]?.name || '';
    });

    overlay.querySelector('#upload-song-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const audioFile = document.getElementById('song-audio-file').files[0];
      if (!audioFile) {
        document.getElementById('upload-song-error').textContent = 'An audio file is required.';
        return;
      }
      const fd = new FormData();
      fd.append('title', document.getElementById('song-title').value.trim());
      fd.append('artistId', document.getElementById('song-artist').value);
      fd.append('albumId', document.getElementById('song-album').value);
      fd.append('genre', document.getElementById('song-genre').value.trim());
      fd.append('trackNumber', document.getElementById('song-track').value);
      fd.append('audio', audioFile);
      const coverFile = document.getElementById('song-cover-file').files[0];
      if (coverFile) fd.append('cover', coverFile);

      const submitBtn = document.getElementById('upload-submit-btn');
      submitBtn.disabled = true;
      submitBtn.textContent = 'Uploading…';
      try {
        await Api.createSong(fd);
        closeModal();
        toast('Song uploaded.');
        loadSongsTable();
      } catch (err) {
        document.getElementById('upload-song-error').textContent = err.message;
        submitBtn.disabled = false;
        submitBtn.textContent = 'Upload';
      }
    });
  }

  async function openEditSongModal(song) {
    await ensureArtistsAlbumsLoaded();
    const overlay = openModal(`
      <h3>Edit song</h3>
      <form id="edit-song-form">
        <div class="field"><label>Title</label><input type="text" id="edit-song-title" value="${escapeHtml(song.title)}" required maxlength="120" /></div>
        <div class="field"><label>Artist</label>
          <select id="edit-song-artist">
            ${cache.artists.map((a) => `<option value="${a.id}" ${a.id === song.artistId ? 'selected' : ''}>${escapeHtml(a.name)}</option>`).join('')}
          </select>
        </div>
        <div class="field"><label>Album</label>
          <select id="edit-song-album">
            <option value="">No album</option>
            ${cache.albums.map((a) => `<option value="${a.id}" ${a.id === song.albumId ? 'selected' : ''}>${escapeHtml(a.title)}</option>`).join('')}
          </select>
        </div>
        <div class="field"><label>Genre</label><input type="text" id="edit-song-genre" value="${escapeHtml(song.genre || '')}" maxlength="40" /></div>
        <div class="field"><label>Track number</label><input type="number" id="edit-song-track" min="1" value="${song.trackNumber || 1}" /></div>
        <div class="field-error" id="edit-song-error"></div>
        <div class="modal-actions">
          <button type="button" class="btn btn-ghost" data-close>Cancel</button>
          <button type="submit" class="btn btn-gradient">Save</button>
        </div>
      </form>
    `);
    overlay.querySelector('#edit-song-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      try {
        await Api.updateSong(song.id, {
          title: document.getElementById('edit-song-title').value.trim(),
          artistId: Number(document.getElementById('edit-song-artist').value),
          albumId: document.getElementById('edit-song-album').value || null,
          genre: document.getElementById('edit-song-genre').value.trim(),
          trackNumber: Number(document.getElementById('edit-song-track').value)
        });
        closeModal();
        toast('Song updated.');
        loadSongsTable();
      } catch (err) {
        document.getElementById('edit-song-error').textContent = err.message;
      }
    });
  }

  // ---------------------------------------------------------------------
  // Albums
  // ---------------------------------------------------------------------

  async function renderAlbums(root) {
    root.innerHTML = `
      <div class="admin-header"><h1>Albums</h1><button class="btn btn-gradient" id="new-album-btn">New album</button></div>
      <div id="albums-table"><div class="skeleton skeleton-row"></div></div>
    `;
    document.getElementById('new-album-btn').addEventListener('click', () => openAlbumModal(null));
    await loadAlbumsTable();
  }

  async function loadAlbumsTable() {
    await ensureArtistsAlbumsLoaded();
    const { albums } = await Api.listAlbums();
    cache.albums = albums;
    const box = document.getElementById('albums-table');
    box.innerHTML = albums.length
      ? `<table class="admin-table"><thead><tr><th>Title</th><th>Artist</th><th>Year</th><th></th></tr></thead><tbody>
          ${albums
            .map(
              (a) => `<tr data-album-id="${a.id}">
                <td><img class="thumb" src="${cover(a, a.title)}" alt="" />${escapeHtml(a.title)}</td>
                <td>${escapeHtml(a.Artist ? a.Artist.name : '—')}</td>
                <td>${a.releaseYear || '—'}</td>
                <td class="row-actions">
                  <button class="btn btn-sm btn-ghost" data-edit-album>Edit</button>
                  <button class="btn btn-sm btn-danger" data-delete-album>Delete</button>
                </td>
              </tr>`
            )
            .join('')}
        </tbody></table>`
      : `<div class="empty-state"><h3>No albums yet</h3></div>`;

    box.querySelectorAll('[data-edit-album]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const id = Number(btn.closest('tr').dataset.albumId);
        openAlbumModal(albums.find((a) => a.id === id));
      });
    });
    box.querySelectorAll('[data-delete-album]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const id = Number(btn.closest('tr').dataset.albumId);
        if (!confirm('Delete this album? Its songs will be kept and unlinked.')) return;
        try {
          await Api.deleteAlbum(id);
          toast('Album deleted.');
          loadAlbumsTable();
        } catch (err) {
          toast(err.message, 'error');
        }
      });
    });
  }

  async function openAlbumModal(album) {
    await ensureArtistsAlbumsLoaded();
    const isEdit = Boolean(album);
    const overlay = openModal(`
      <h3>${isEdit ? 'Edit album' : 'New album'}</h3>
      <form id="album-form">
        <div class="field"><label>Title</label><input type="text" id="album-title" value="${isEdit ? escapeHtml(album.title) : ''}" required maxlength="120" /></div>
        <div class="field"><label>Artist</label>
          <select id="album-artist" required>
            <option value="">Select an artist…</option>
            ${cache.artists.map((a) => `<option value="${a.id}" ${isEdit && a.id === album.artistId ? 'selected' : ''}>${escapeHtml(a.name)}</option>`).join('')}
          </select>
        </div>
        <div class="field"><label>Release year</label><input type="number" id="album-year" value="${isEdit ? album.releaseYear || '' : ''}" min="1900" max="2100" /></div>
        <div class="field"><label>Genre</label><input type="text" id="album-genre" value="${isEdit ? escapeHtml(album.genre || '') : ''}" maxlength="40" /></div>
        <div class="field">
          <label>Cover image</label>
          <label class="upload-dropzone">
            Click to choose a cover image
            <input type="file" id="album-cover-file" accept="image/jpeg,image/png,image/webp" />
            <div class="upload-file-name" id="album-cover-name"></div>
          </label>
        </div>
        <div class="field-error" id="album-form-error"></div>
        <div class="modal-actions">
          <button type="button" class="btn btn-ghost" data-close>Cancel</button>
          <button type="submit" class="btn btn-gradient">${isEdit ? 'Save' : 'Create'}</button>
        </div>
      </form>
    `);
    overlay.querySelector('#album-cover-file').addEventListener('change', (e) => {
      document.getElementById('album-cover-name').textContent = e.target.files[0]?.name || '';
    });
    overlay.querySelector('#album-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData();
      fd.append('title', document.getElementById('album-title').value.trim());
      fd.append('artistId', document.getElementById('album-artist').value);
      fd.append('releaseYear', document.getElementById('album-year').value);
      fd.append('genre', document.getElementById('album-genre').value.trim());
      const coverFile = document.getElementById('album-cover-file').files[0];
      if (coverFile) fd.append('cover', coverFile);

      try {
        if (isEdit) await Api.updateAlbum(album.id, fd);
        else await Api.createAlbum(fd);
        closeModal();
        toast(isEdit ? 'Album updated.' : 'Album created.');
        loadAlbumsTable();
      } catch (err) {
        document.getElementById('album-form-error').textContent = err.message;
      }
    });
  }

  // ---------------------------------------------------------------------
  // Artists
  // ---------------------------------------------------------------------

  async function renderArtists(root) {
    root.innerHTML = `
      <div class="admin-header"><h1>Artists</h1><button class="btn btn-gradient" id="new-artist-btn">New artist</button></div>
      <div id="artists-table"><div class="skeleton skeleton-row"></div></div>
    `;
    document.getElementById('new-artist-btn').addEventListener('click', () => openArtistModal(null));
    await loadArtistsTable();
  }

  async function loadArtistsTable() {
    const { artists } = await Api.listArtists();
    cache.artists = artists;
    const box = document.getElementById('artists-table');
    box.innerHTML = artists.length
      ? `<table class="admin-table"><thead><tr><th>Name</th><th>Genre</th><th></th></tr></thead><tbody>
          ${artists
            .map(
              (a) => `<tr data-artist-id="${a.id}">
                <td><img class="thumb" src="${cover(a, a.name)}" alt="" style="border-radius:50%;" />${escapeHtml(a.name)}</td>
                <td>${escapeHtml(a.genre || '—')}</td>
                <td class="row-actions">
                  <button class="btn btn-sm btn-ghost" data-edit-artist>Edit</button>
                  <button class="btn btn-sm btn-danger" data-delete-artist>Delete</button>
                </td>
              </tr>`
            )
            .join('')}
        </tbody></table>`
      : `<div class="empty-state"><h3>No artists yet</h3></div>`;

    box.querySelectorAll('[data-edit-artist]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const id = Number(btn.closest('tr').dataset.artistId);
        openArtistModal(artists.find((a) => a.id === id));
      });
    });
    box.querySelectorAll('[data-delete-artist]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const id = Number(btn.closest('tr').dataset.artistId);
        if (!confirm('Delete this artist? This is blocked if they still have songs.')) return;
        try {
          await Api.deleteArtist(id);
          toast('Artist deleted.');
          loadArtistsTable();
        } catch (err) {
          toast(err.message, 'error');
        }
      });
    });
  }

  function openArtistModal(artist) {
    const isEdit = Boolean(artist);
    const overlay = openModal(`
      <h3>${isEdit ? 'Edit artist' : 'New artist'}</h3>
      <form id="artist-form">
        <div class="field"><label>Name</label><input type="text" id="artist-name" value="${isEdit ? escapeHtml(artist.name) : ''}" required maxlength="80" /></div>
        <div class="field"><label>Genre</label><input type="text" id="artist-genre" value="${isEdit ? escapeHtml(artist.genre || '') : ''}" maxlength="40" /></div>
        <div class="field"><label>Bio</label><textarea id="artist-bio" maxlength="500">${isEdit ? escapeHtml(artist.bio || '') : ''}</textarea></div>
        <div class="field">
          <label>Photo</label>
          <label class="upload-dropzone">
            Click to choose a photo
            <input type="file" id="artist-image-file" accept="image/jpeg,image/png,image/webp" />
            <div class="upload-file-name" id="artist-image-name"></div>
          </label>
        </div>
        <div class="field-error" id="artist-form-error"></div>
        <div class="modal-actions">
          <button type="button" class="btn btn-ghost" data-close>Cancel</button>
          <button type="submit" class="btn btn-gradient">${isEdit ? 'Save' : 'Create'}</button>
        </div>
      </form>
    `);
    overlay.querySelector('#artist-image-file').addEventListener('change', (e) => {
      document.getElementById('artist-image-name').textContent = e.target.files[0]?.name || '';
    });
    overlay.querySelector('#artist-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData();
      fd.append('name', document.getElementById('artist-name').value.trim());
      fd.append('genre', document.getElementById('artist-genre').value.trim());
      fd.append('bio', document.getElementById('artist-bio').value.trim());
      const imageFile = document.getElementById('artist-image-file').files[0];
      if (imageFile) fd.append('image', imageFile);

      try {
        if (isEdit) await Api.updateArtist(artist.id, fd);
        else await Api.createArtist(fd);
        closeModal();
        toast(isEdit ? 'Artist updated.' : 'Artist created.');
        loadArtistsTable();
      } catch (err) {
        document.getElementById('artist-form-error').textContent = err.message;
      }
    });
  }

  // ---------------------------------------------------------------------
  // Playlists (admin can see public playlists + their own, and delete any)
  // ---------------------------------------------------------------------

  async function renderPlaylists(root) {
    root.innerHTML = `<div class="admin-header"><h1>Playlists</h1></div><div id="playlists-table"><div class="skeleton skeleton-row"></div></div>`;
    const { playlists } = await Api.listPlaylists();
    const box = document.getElementById('playlists-table');
    box.innerHTML = playlists.length
      ? `<table class="admin-table"><thead><tr><th>Name</th><th>Owner</th><th>Visibility</th><th></th></tr></thead><tbody>
          ${playlists
            .map(
              (p) => `<tr data-playlist-id="${p.id}">
                <td>${escapeHtml(p.name)}</td>
                <td>${escapeHtml(p.owner ? p.owner.username : '—')}</td>
                <td>${p.isPublic ? 'Public' : 'Private'}</td>
                <td class="row-actions"><button class="btn btn-sm btn-danger" data-delete-playlist>Delete</button></td>
              </tr>`
            )
            .join('')}
        </tbody></table>`
      : `<div class="empty-state"><h3>No playlists yet</h3></div>`;

    box.querySelectorAll('[data-delete-playlist]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const id = Number(btn.closest('tr').dataset.playlistId);
        if (!confirm('Delete this playlist?')) return;
        try {
          await Api.deletePlaylist(id);
          toast('Playlist deleted.');
          renderPlaylists(root);
        } catch (err) {
          toast(err.message, 'error');
        }
      });
    });
  }

  // ---------------------------------------------------------------------
  // Users
  // ---------------------------------------------------------------------

  async function renderUsers(root) {
    root.innerHTML = `<div class="admin-header"><h1>Users</h1></div><div id="users-table"><div class="skeleton skeleton-row"></div></div>`;
    const { users } = await Api.adminListUsers();
    const me = Api.getStoredUser();
    const box = document.getElementById('users-table');
    box.innerHTML = `<table class="admin-table"><thead><tr><th>Username</th><th>Email</th><th>Role</th><th></th></tr></thead><tbody>
        ${users
          .map(
            (u) => `<tr data-user-id="${u.id}">
              <td>${escapeHtml(u.username)}</td>
              <td>${escapeHtml(u.email)}</td>
              <td><span class="role-badge ${u.role === 'admin' ? 'admin' : ''}">${u.role}</span></td>
              <td class="row-actions">
                <button class="btn btn-sm btn-ghost" data-toggle-role>${u.role === 'admin' ? 'Make user' : 'Make admin'}</button>
                <button class="btn btn-sm btn-danger" data-delete-user ${u.id === me?.id ? 'disabled title="You cannot delete your own account"' : ''}>Delete</button>
              </td>
            </tr>`
          )
          .join('')}
      </tbody></table>`;

    box.querySelectorAll('[data-toggle-role]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const tr = btn.closest('tr');
        const id = Number(tr.dataset.userId);
        const user = users.find((u) => u.id === id);
        const newRole = user.role === 'admin' ? 'user' : 'admin';
        try {
          await Api.adminSetUserRole(id, newRole);
          toast('Role updated.');
          renderUsers(root);
        } catch (err) {
          toast(err.message, 'error');
        }
      });
    });
    box.querySelectorAll('[data-delete-user]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        if (btn.disabled) return;
        const id = Number(btn.closest('tr').dataset.userId);
        if (!confirm('Delete this user account?')) return;
        try {
          await Api.adminDeleteUser(id);
          toast('User deleted.');
          renderUsers(root);
        } catch (err) {
          toast(err.message, 'error');
        }
      });
    });
  }

  // ---------------------------------------------------------------------
  // Tab routing
  // ---------------------------------------------------------------------

  const TABS = { overview: renderOverview, songs: renderSongs, albums: renderAlbums, artists: renderArtists, playlists: renderPlaylists, users: renderUsers };

  function setActiveTab(tab) {
    currentTab = tab;
    document.querySelectorAll('.admin-sidebar .nav-item').forEach((btn) => btn.classList.toggle('active', btn.dataset.tab === tab));
    const root = document.getElementById('admin-tab-root');
    TABS[tab](root).catch((err) => {
      root.innerHTML = `<div class="empty-state"><h3>Something went wrong</h3><p>${escapeHtml(err.message)}</p></div>`;
    });
  }

  function wireTabs() {
    document.querySelectorAll('.admin-sidebar .nav-item').forEach((btn) => {
      btn.addEventListener('click', () => setActiveTab(btn.dataset.tab));
    });
  }

  // ---------------------------------------------------------------------
  // Boot: gate on admin role
  // ---------------------------------------------------------------------

  async function boot() {
    if (!Api.getToken()) {
      document.getElementById('gate-message').textContent = 'Please log in to Auralis first, then return here.';
      return;
    }
    try {
      const { user } = await Api.me();
      if (user.role !== 'admin') {
        document.getElementById('gate-message').textContent = 'Your account does not have admin access.';
        return;
      }
      document.getElementById('admin-gate').classList.add('hidden');
      document.getElementById('admin-app').classList.remove('hidden');
      wireTabs();
      setActiveTab('overview');
    } catch (err) {
      document.getElementById('gate-message').textContent = 'Your session has expired. Please log in again.';
    }
  }

  document.addEventListener('DOMContentLoaded', boot);
})();
