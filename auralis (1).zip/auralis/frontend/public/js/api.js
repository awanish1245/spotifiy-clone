// js/api.js
// Thin wrapper around fetch() for talking to the Auralis REST API.
// Since the frontend is served by the same Express server, relative
// paths are used and no base URL configuration is needed.

const Api = (() => {
  const TOKEN_KEY = 'auralis_token';
  const USER_KEY = 'auralis_user';

  function getToken() {
    return localStorage.getItem(TOKEN_KEY);
  }

  function setSession(token, user) {
    localStorage.setItem(TOKEN_KEY, token);
    localStorage.setItem(USER_KEY, JSON.stringify(user));
  }

  function clearSession() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
  }

  function getStoredUser() {
    try {
      return JSON.parse(localStorage.getItem(USER_KEY));
    } catch {
      return null;
    }
  }

  /**
   * Core request helper. `body` may be a plain object (sent as JSON) or a
   * FormData instance (sent as-is, for file uploads).
   */
  async function request(method, path, { body, isForm } = {}) {
    const headers = {};
    const token = getToken();
    if (token) headers.Authorization = `Bearer ${token}`;
    if (body && !isForm) headers['Content-Type'] = 'application/json';

    const res = await fetch(path, {
      method,
      headers,
      body: body ? (isForm ? body : JSON.stringify(body)) : undefined
    });

    let data = null;
    const text = await res.text();
    if (text) {
      try {
        data = JSON.parse(text);
      } catch {
        data = null;
      }
    }

    if (!res.ok) {
      const message = (data && data.message) || `Request failed with status ${res.status}`;
      const err = new Error(message);
      err.status = res.status;
      err.details = data && data.details;
      throw err;
    }

    return data;
  }

  const get = (path) => request('GET', path);
  const post = (path, body, opts) => request('POST', path, { body, ...opts });
  const put = (path, body, opts) => request('PUT', path, { body, ...opts });
  const patch = (path, body, opts) => request('PATCH', path, { body, ...opts });
  const del = (path) => request('DELETE', path);

  return {
    getToken,
    setSession,
    clearSession,
    getStoredUser,

    // ---- Auth ----
    register: (payload) => post('/api/auth/register', payload),
    login: (payload) => post('/api/auth/login', payload),
    me: () => get('/api/auth/me'),
    logout: () => post('/api/auth/logout'),

    // ---- Songs ----
    listSongs: (params = '') => get(`/api/songs${params}`),
    getSong: (id) => get(`/api/songs/${id}`),
    createSong: (formData) => post('/api/songs', formData, { isForm: true }),
    updateSong: (id, payload) => put(`/api/songs/${id}`, payload),
    deleteSong: (id) => del(`/api/songs/${id}`),
    streamUrl: (id) => `/api/songs/${id}/stream`,

    // ---- Artists ----
    listArtists: () => get('/api/artists'),
    getArtist: (id) => get(`/api/artists/${id}`),
    createArtist: (formData) => post('/api/artists', formData, { isForm: true }),
    updateArtist: (id, formData) => put(`/api/artists/${id}`, formData, { isForm: true }),
    deleteArtist: (id) => del(`/api/artists/${id}`),

    // ---- Albums ----
    listAlbums: () => get('/api/albums'),
    getAlbum: (id) => get(`/api/albums/${id}`),
    createAlbum: (formData) => post('/api/albums', formData, { isForm: true }),
    updateAlbum: (id, formData) => put(`/api/albums/${id}`, formData, { isForm: true }),
    deleteAlbum: (id) => del(`/api/albums/${id}`),

    // ---- Playlists ----
    listPlaylists: () => get('/api/playlists'),
    getPlaylist: (id) => get(`/api/playlists/${id}`),
    createPlaylist: (payload) => post('/api/playlists', payload),
    updatePlaylist: (id, payload) => put(`/api/playlists/${id}`, payload),
    deletePlaylist: (id) => del(`/api/playlists/${id}`),
    addSongToPlaylist: (id, songId) => post(`/api/playlists/${id}/songs`, { songId }),
    removeSongFromPlaylist: (id, songId) => del(`/api/playlists/${id}/songs/${songId}`),
    reorderPlaylist: (id, songIds) => patch(`/api/playlists/${id}/reorder`, { songIds }),

    // ---- Favorites ----
    listFavorites: () => get('/api/favorites'),
    addFavorite: (songId) => post('/api/favorites', { songId }),
    removeFavorite: (songId) => del(`/api/favorites/${songId}`),

    // ---- History ----
    getRecentlyPlayed: () => get('/api/history/recent'),
    getFullHistory: (params = '') => get(`/api/history/full${params}`),
    logPlay: (songId) => post('/api/history', { songId }),

    // ---- Search ----
    globalSearch: (q) => get(`/api/search?q=${encodeURIComponent(q)}`),

    // ---- Admin ----
    adminStats: () => get('/api/admin/stats'),
    adminListUsers: () => get('/api/admin/users'),
    adminSetUserRole: (id, role) => put(`/api/admin/users/${id}/role`, { role }),
    adminDeleteUser: (id) => del(`/api/admin/users/${id}`)
  };
})();
