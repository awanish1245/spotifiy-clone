// js/player.js
// Core playback engine, decoupled from UI rendering (app.js listens to the
// events this module emits and updates the DOM accordingly).

const Player = (() => {
  const audio = new Audio();
  audio.preload = 'metadata';

  let queue = [];        // array of song objects, in original order
  let playOrder = [];     // array of indices into `queue`, defines play sequence (shuffled or not)
  let orderPos = -1;      // current position within playOrder
  let shuffle = false;
  let repeatMode = 'off'; // 'off' | 'all' | 'one'
  let audioCtx = null;
  let analyser = null;
  let sourceNode = null;

  const listeners = {
    trackchange: [],
    play: [],
    pause: [],
    timeupdate: [],
    queuechange: []
  };

  function emit(evt, payload) {
    listeners[evt].forEach((fn) => fn(payload));
  }
  function on(evt, fn) {
    listeners[evt].push(fn);
  }

  function currentSong() {
    if (orderPos < 0 || orderPos >= playOrder.length) return null;
    return queue[playOrder[orderPos]];
  }

  function buildOrder(startAtIndex = 0) {
    const indices = queue.map((_, i) => i);
    if (shuffle) {
      // Fisher-Yates, but keep the requested start track first.
      for (let i = indices.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [indices[i], indices[j]] = [indices[j], indices[i]];
      }
      const idx = indices.indexOf(startAtIndex);
      if (idx > -1) {
        indices.splice(idx, 1);
        indices.unshift(startAtIndex);
      }
    } else {
      // Rotate so playback starts at the requested index but order stays sequential.
      const before = indices.slice(0, startAtIndex);
      const from = indices.slice(startAtIndex);
      return from.concat(before);
    }
    return indices;
  }

  /** Loads a new queue and starts playback at `startIndex` (default 0). */
  function loadQueue(songs, startIndex = 0) {
    queue = songs.slice();
    playOrder = buildOrder(startIndex);
    orderPos = 0;
    emit('queuechange', { queue, playOrder });
    playCurrent();
  }

  /** Appends songs to the end of the existing queue without interrupting playback. */
  function enqueue(songs) {
    const startLen = queue.length;
    queue = queue.concat(songs);
    const newIndices = songs.map((_, i) => startLen + i);
    playOrder = playOrder.concat(newIndices);
    emit('queuechange', { queue, playOrder });
  }

  function setupAnalyser() {
    if (audioCtx) return;
    try {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      sourceNode = audioCtx.createMediaElementSource(audio);
      analyser = audioCtx.createAnalyser();
      analyser.fftSize = 128;
      sourceNode.connect(analyser);
      analyser.connect(audioCtx.destination);
    } catch (err) {
      console.warn('Audio visualizer unavailable:', err.message);
    }
  }

  function getAnalyser() {
    return analyser;
  }

  function playCurrent() {
    const song = currentSong();
    if (!song) return;
    audio.src = Api.streamUrl(song.id);
    setupAnalyser();
    if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
    audio.play().catch(() => {
      /* Autoplay may be blocked until a user gesture; the UI stays in a
         paused state and the user can press play again. */
    });
    emit('trackchange', song);
    if (Api.getToken()) Api.logPlay(song.id).catch(() => {});
    updateMediaSession(song);
  }

  function play() {
    if (!currentSong()) return;
    if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
    audio.play().catch(() => {});
  }

  function pause() {
    audio.pause();
  }

  function togglePlay() {
    if (audio.paused) play();
    else pause();
  }

  function next({ userInitiated = true } = {}) {
    if (!playOrder.length) return;
    if (orderPos < playOrder.length - 1) {
      orderPos += 1;
    } else if (repeatMode === 'all') {
      orderPos = 0;
    } else {
      if (userInitiated) {
        // At the end with repeat off: stop rather than wrap.
        audio.pause();
        audio.currentTime = 0;
      }
      return;
    }
    playCurrent();
  }

  function prev() {
    if (!playOrder.length) return;
    // If more than 3s into the track, restart it instead of going back a track.
    if (audio.currentTime > 3) {
      audio.currentTime = 0;
      return;
    }
    if (orderPos > 0) {
      orderPos -= 1;
    } else if (repeatMode === 'all') {
      orderPos = playOrder.length - 1;
    } else {
      audio.currentTime = 0;
      return;
    }
    playCurrent();
  }

  function seekTo(seconds) {
    if (Number.isFinite(seconds)) audio.currentTime = seconds;
  }

  function setVolume(v) {
    audio.volume = Math.max(0, Math.min(1, v));
    if (audio.volume > 0) audio.muted = false;
  }

  function toggleMute() {
    audio.muted = !audio.muted;
    return audio.muted;
  }

  function setShuffle(on) {
    shuffle = on;
    const startIndex = currentSong() ? playOrder[orderPos] : 0;
    playOrder = buildOrder(startIndex);
    orderPos = 0;
    emit('queuechange', { queue, playOrder });
  }

  function cycleRepeat() {
    repeatMode = repeatMode === 'off' ? 'all' : repeatMode === 'all' ? 'one' : 'off';
    return repeatMode;
  }

  function setSpeed(rate) {
    audio.playbackRate = rate;
  }

  function updateMediaSession(song) {
    if (!('mediaSession' in navigator)) return;
    navigator.mediaSession.metadata = new MediaMetadata({
      title: song.title,
      artist: song.Artist ? song.Artist.name : 'Unknown artist',
      album: song.Album ? song.Album.title : '',
      artwork: song.coverUrl ? [{ src: song.coverUrl, sizes: '512x512', type: 'image/svg+xml' }] : []
    });
    navigator.mediaSession.setActionHandler('play', play);
    navigator.mediaSession.setActionHandler('pause', pause);
    navigator.mediaSession.setActionHandler('previoustrack', prev);
    navigator.mediaSession.setActionHandler('nexttrack', () => next());
    navigator.mediaSession.setActionHandler('seekto', (details) => {
      if (details.seekTime != null) seekTo(details.seekTime);
    });
  }

  // ---- Native <audio> event wiring ----
  audio.addEventListener('play', () => emit('play'));
  audio.addEventListener('pause', () => emit('pause'));
  audio.addEventListener('timeupdate', () => emit('timeupdate', { currentTime: audio.currentTime, duration: audio.duration }));
  audio.addEventListener('ended', () => {
    if (repeatMode === 'one') {
      audio.currentTime = 0;
      audio.play().catch(() => {});
    } else {
      next({ userInitiated: false });
    }
  });

  // ---- Keyboard shortcuts ----
  document.addEventListener('keydown', (e) => {
    const tag = (e.target.tagName || '').toLowerCase();
    if (tag === 'input' || tag === 'textarea') return; // don't hijack typing

    if (e.code === 'Space') {
      e.preventDefault();
      togglePlay();
    } else if (e.code === 'ArrowRight' && e.ctrlKey) {
      next();
    } else if (e.code === 'ArrowLeft' && e.ctrlKey) {
      prev();
    } else if (e.code === 'ArrowRight' && !e.ctrlKey && document.activeElement.id !== 'seek-slider') {
      seekTo(audio.currentTime + 5);
    } else if (e.code === 'ArrowLeft' && !e.ctrlKey && document.activeElement.id !== 'seek-slider') {
      seekTo(audio.currentTime - 5);
    } else if (e.key.toLowerCase() === 'm') {
      toggleMute();
    } else if (e.key.toLowerCase() === 's') {
      setShuffle(!shuffle);
      emit('shufflechange', shuffle);
    } else if (e.key.toLowerCase() === 'r') {
      const mode = cycleRepeat();
      emit('repeatchange', mode);
    }
  });

  return {
    on,
    loadQueue,
    enqueue,
    play,
    pause,
    togglePlay,
    next,
    prev,
    seekTo,
    setVolume,
    toggleMute,
    setShuffle,
    cycleRepeat,
    setSpeed,
    currentSong,
    getAnalyser,
    get audioEl() { return audio; },
    get isShuffled() { return shuffle; },
    get repeatMode() { return repeatMode; },
    get queueSongs() { return queue; }
  };
})();
