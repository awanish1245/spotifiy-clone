// server.js
// Entry point for the Auralis backend API.
require('dotenv').config();

const path = require('path');
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');

const { connectDB } = require('./config/db');
const { syncModels } = require('./models');
const { notFound, errorHandler } = require('./middleware/errorHandler');

const authRoutes = require('./routes/auth');
const songRoutes = require('./routes/songs');
const artistRoutes = require('./routes/artists');
const albumRoutes = require('./routes/albums');
const playlistRoutes = require('./routes/playlists');
const favoriteRoutes = require('./routes/favorites');
const historyRoutes = require('./routes/history');
const searchRoutes = require('./routes/search');
const adminRoutes = require('./routes/admin');

const app = express();

// ---- Global middleware ----
app.use(cors({ origin: process.env.CORS_ORIGIN || '*' }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(morgan('dev'));

// ---- Static files ----
// Uploaded audio/cover files (served with range-request support handled per-route for songs).
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
// The frontend (plain HTML/CSS/JS) is served directly by this same server
// so the whole app runs from a single `npm start` with no separate build step.
app.use(express.static(path.join(__dirname, '..', 'frontend', 'public')));

// ---- API routes ----
app.use('/api/auth', authRoutes);
app.use('/api/songs', songRoutes);
app.use('/api/artists', artistRoutes);
app.use('/api/albums', albumRoutes);
app.use('/api/playlists', playlistRoutes);
app.use('/api/favorites', favoriteRoutes);
app.use('/api/history', historyRoutes);
app.use('/api/search', searchRoutes);
app.use('/api/admin', adminRoutes);

app.get('/api/health', (req, res) => res.json({ status: 'ok', service: 'auralis-api' }));

// Any non-API GET request falls back to the SPA shell so client-side
// routing (e.g. refreshing on /admin) keeps working.
app.get(/^\/(?!api|uploads).*/, (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'frontend', 'public', 'index.html'));
});

app.use(notFound);
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

async function start() {
  await connectDB();
  await syncModels();
  app.listen(PORT, () => {
    console.log(`[server] Auralis API listening on http://localhost:${PORT}`);
  });
}

start();

module.exports = app;
