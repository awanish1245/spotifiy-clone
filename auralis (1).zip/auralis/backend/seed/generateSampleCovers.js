// seed/generateSampleCovers.js
//
// Generates simple original placeholder cover art as SVG files (gradient +
// initials), so albums/artists/playlists have visuals out of the box
// without bundling any copyrighted artwork. Replace via the admin panel
// with real cover uploads (jpg/png/webp) at any time.

const fs = require('fs');
const path = require('path');

const OUT_DIR = path.join(__dirname, '..', 'uploads', 'covers');
if (!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive: true });

const GRADIENTS = [
  ['#6C5CE7', '#00CEC9'],
  ['#FD79A8', '#6C5CE7'],
  ['#00B894', '#00CEC9'],
  ['#E17055', '#FDCB6E'],
  ['#0984E3', '#6C5CE7'],
  ['#D63031', '#FD79A8'],
  ['#00CEC9', '#0984E3'],
  ['#FDCB6E', '#E17055']
];

function initials(name) {
  return name
    .split(' ')
    .map((w) => w[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();
}

function makeCoverSvg(filename, label, gradientIdx) {
  const [c1, c2] = GRADIENTS[gradientIdx % GRADIENTS.length];
  const id = `g${gradientIdx}`;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300">
  <defs>
    <linearGradient id="${id}" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="${c1}"/>
      <stop offset="100%" stop-color="${c2}"/>
    </linearGradient>
  </defs>
  <rect width="300" height="300" fill="url(#${id})"/>
  <text x="150" y="170" font-family="Helvetica, Arial, sans-serif" font-size="96" font-weight="700"
        fill="rgba(255,255,255,0.92)" text-anchor="middle">${initials(label)}</text>
</svg>`;
  fs.writeFileSync(path.join(OUT_DIR, filename), svg);
  return filename;
}

module.exports = { makeCoverSvg, OUT_DIR };
