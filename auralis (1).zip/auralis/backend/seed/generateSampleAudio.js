// seed/generateSampleAudio.js
//
// Generates a handful of short, original WAV audio files using simple sine
// wave synthesis. These are placeholders so the app is playable immediately
// after installation without requiring the developer to source real MP3s
// (which this project deliberately does not include, for copyright
// reasons - see README "Sample Audio" section). Replace them with your own
// licensed or original MP3/WAV files any time via the admin upload panel.
//
// No external dependencies: writes a raw 16-bit PCM WAV file by hand.

const fs = require('fs');
const path = require('path');

const OUT_DIR = path.join(__dirname, '..', 'uploads', 'songs');
if (!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive: true });

function writeWavTone({ filename, durationSeconds, frequencies, sampleRate = 44100 }) {
  const numSamples = Math.floor(durationSeconds * sampleRate);
  const bytesPerSample = 2; // 16-bit
  const numChannels = 1;
  const blockAlign = numChannels * bytesPerSample;
  const byteRate = sampleRate * blockAlign;
  const dataSize = numSamples * blockAlign;

  const buffer = Buffer.alloc(44 + dataSize);

  // RIFF header
  buffer.write('RIFF', 0);
  buffer.writeUInt32LE(36 + dataSize, 4);
  buffer.write('WAVE', 8);

  // fmt chunk
  buffer.write('fmt ', 12);
  buffer.writeUInt32LE(16, 16); // PCM chunk size
  buffer.writeUInt16LE(1, 20); // audio format = PCM
  buffer.writeUInt16LE(numChannels, 22);
  buffer.writeUInt32LE(sampleRate, 24);
  buffer.writeUInt32LE(byteRate, 28);
  buffer.writeUInt16LE(blockAlign, 32);
  buffer.writeUInt16LE(bytesPerSample * 8, 34);

  // data chunk
  buffer.write('data', 36);
  buffer.writeUInt32LE(dataSize, 40);

  // Simple chord/arpeggio synthesis with a fade-in/out envelope so the
  // placeholder tracks don't click or feel like a raw test tone.
  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    let sample = 0;
    frequencies.forEach((freq) => {
      sample += Math.sin(2 * Math.PI * freq * t);
    });
    sample /= frequencies.length;

    // Gentle envelope: fade in over 0.5s, fade out over the last 0.5s.
    const fadeTime = 0.5;
    let envelope = 1;
    if (t < fadeTime) envelope = t / fadeTime;
    else if (t > durationSeconds - fadeTime) envelope = Math.max(0, (durationSeconds - t) / fadeTime);

    const value = Math.max(-1, Math.min(1, sample * envelope * 0.5));
    buffer.writeInt16LE(Math.round(value * 32767), 44 + i * blockAlign);
  }

  fs.writeFileSync(path.join(OUT_DIR, filename), buffer);
  return { filename, duration: durationSeconds };
}

// Musical note frequencies (Hz), used to build simple original chord progressions.
const NOTE = { C4: 261.63, E4: 329.63, G4: 392.0, A4: 440.0, D4: 293.66, F4: 349.23, B3: 246.94, G3: 196.0 };

const SAMPLE_TRACKS = [
  { filename: 'sample-01-midnight-drive.wav', durationSeconds: 20, frequencies: [NOTE.C4, NOTE.E4, NOTE.G4] },
  { filename: 'sample-02-golden-hour.wav', durationSeconds: 18, frequencies: [NOTE.A4, NOTE.D4, NOTE.F4] },
  { filename: 'sample-03-city-lights.wav', durationSeconds: 22, frequencies: [NOTE.G3, NOTE.B3, NOTE.D4] },
  { filename: 'sample-04-open-road.wav', durationSeconds: 19, frequencies: [NOTE.C4, NOTE.F4, NOTE.A4] },
  { filename: 'sample-05-quiet-static.wav', durationSeconds: 21, frequencies: [NOTE.D4, NOTE.G4, NOTE.B3] },
  { filename: 'sample-06-afterglow.wav', durationSeconds: 17, frequencies: [NOTE.E4, NOTE.G4, NOTE.C4] },
  { filename: 'sample-07-neon-rain.wav', durationSeconds: 23, frequencies: [NOTE.A4, NOTE.C4, NOTE.E4] },
  { filename: 'sample-08-slow-orbit.wav', durationSeconds: 20, frequencies: [NOTE.F4, NOTE.A4, NOTE.D4] }
];

function generateAll() {
  const results = SAMPLE_TRACKS.map(writeWavTone);
  console.log(`[seed] Generated ${results.length} sample WAV files in ${OUT_DIR}`);
  return results;
}

if (require.main === module) {
  generateAll();
}

module.exports = { generateAll, SAMPLE_TRACKS };
