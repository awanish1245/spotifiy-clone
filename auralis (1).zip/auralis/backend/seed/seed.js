// seed/seed.js
// Populates the database with sample data so the app is fully explorable
// immediately after installation. Run with: npm run seed
//
// Safe to re-run: it clears existing rows first (local dev data only).

require('dotenv').config();
const bcrypt = require('bcryptjs');
const { sequelize, User, Artist, Album, Song, Playlist, PlaylistSong, Favorite, RecentlyPlayed, syncModels } = require('../models');
const { generateAll } = require('./generateSampleAudio');
const { makeCoverSvg } = require('./generateSampleCovers');

async function seed() {
  await syncModels();

  console.log('[seed] Clearing existing data...');
  await PlaylistSong.destroy({ where: {}, truncate: true });
  await Favorite.destroy({ where: {}, truncate: true });
  await RecentlyPlayed.destroy({ where: {}, truncate: true });
  await Playlist.destroy({ where: {}, truncate: true });
  await Song.destroy({ where: {}, truncate: true });
  await Album.destroy({ where: {}, truncate: true });
  await Artist.destroy({ where: {}, truncate: true });
  await User.destroy({ where: {}, truncate: true });

  console.log('[seed] Generating sample audio files...');
  const tracks = generateAll();

  console.log('[seed] Creating users...');
  const adminPasswordHash = await bcrypt.hash('Admin123!', 10);
  const userPasswordHash = await bcrypt.hash('Listener123!', 10);

  const admin = await User.create({
    username: 'admin',
    email: 'admin@auralis.local',
    passwordHash: adminPasswordHash,
    role: 'admin'
  });

  const listener = await User.create({
    username: 'demo_listener',
    email: 'listener@auralis.local',
    passwordHash: userPasswordHash,
    role: 'user'
  });

  console.log('[seed] Creating artists...');
  const artistDefs = [
    { name: 'Nova Ridge', genre: 'Synthwave', bio: 'A studio project blending analog synths with driving night-time rhythms.' },
    { name: 'Marigold Static', genre: 'Indie Pop', bio: 'Warm, hazy indie pop built around tape loops and close harmonies.' },
    { name: 'The Quiet Hours', genre: 'Lo-fi', bio: 'Instrumental lo-fi for late nights and long commutes.' },
    { name: 'Echo Parade', genre: 'Alternative', bio: 'Anthemic alternative rock with a cinematic edge.' }
  ];

  const artists = [];
  for (let i = 0; i < artistDefs.length; i++) {
    const def = artistDefs[i];
    const imageFile = `artist-${i + 1}.svg`;
    makeCoverSvg(imageFile, def.name, i);
    const artist = await Artist.create({ ...def, imageUrl: `/uploads/covers/${imageFile}` });
    artists.push(artist);
  }

  console.log('[seed] Creating albums...');
  const albumDefs = [
    { title: 'Night Drive', artist: artists[0], releaseYear: 2024, genre: 'Synthwave' },
    { title: 'Sun-Faded', artist: artists[1], releaseYear: 2023, genre: 'Indie Pop' },
    { title: 'Slow Rooms', artist: artists[2], releaseYear: 2022, genre: 'Lo-fi' },
    { title: 'Signal Fires', artist: artists[3], releaseYear: 2024, genre: 'Alternative' }
  ];

  const albums = [];
  for (let i = 0; i < albumDefs.length; i++) {
    const def = albumDefs[i];
    const coverFile = `album-${i + 1}.svg`;
    makeCoverSvg(coverFile, def.title, i + 4);
    const album = await Album.create({
      title: def.title,
      artistId: def.artist.id,
      releaseYear: def.releaseYear,
      genre: def.genre,
      coverUrl: `/uploads/covers/${coverFile}`
    });
    albums.push(album);
  }

  console.log('[seed] Creating songs...');
  const songDefs = [
    { title: 'Midnight Drive', artist: artists[0], album: albums[0], genre: 'Synthwave', track: 1, file: tracks[0] },
    { title: 'Golden Hour', artist: artists[1], album: albums[1], genre: 'Indie Pop', track: 1, file: tracks[1] },
    { title: 'City Lights', artist: artists[0], album: albums[0], genre: 'Synthwave', track: 2, file: tracks[2] },
    { title: 'Open Road', artist: artists[3], album: albums[3], genre: 'Alternative', track: 1, file: tracks[3] },
    { title: 'Quiet Static', artist: artists[2], album: albums[2], genre: 'Lo-fi', track: 1, file: tracks[4] },
    { title: 'Afterglow', artist: artists[1], album: albums[1], genre: 'Indie Pop', track: 2, file: tracks[5] },
    { title: 'Neon Rain', artist: artists[0], album: albums[0], genre: 'Synthwave', track: 3, file: tracks[6] },
    { title: 'Slow Orbit', artist: artists[2], album: albums[2], genre: 'Lo-fi', track: 2, file: tracks[7] }
  ];

  const songs = [];
  for (const def of songDefs) {
    const song = await Song.create({
      title: def.title,
      artistId: def.artist.id,
      albumId: def.album.id,
      genre: def.genre,
      trackNumber: def.track,
      duration: def.file.duration,
      filePath: `songs/${def.file.filename}`,
      coverUrl: def.album.coverUrl,
      playCount: Math.floor(Math.random() * 500)
    });
    songs.push(song);
  }

  console.log('[seed] Creating playlists...');
  const chill = await Playlist.create({
    name: 'Late Night Chill',
    description: 'Mellow tracks for winding down.',
    ownerId: listener.id,
    isPublic: true
  });
  const driveMix = await Playlist.create({
    name: 'Drive Mix',
    description: 'Synth-driven tracks for the road.',
    ownerId: admin.id,
    isPublic: true
  });

  await PlaylistSong.bulkCreate([
    { playlistId: chill.id, songId: songs[4].id, position: 0 },
    { playlistId: chill.id, songId: songs[7].id, position: 1 },
    { playlistId: chill.id, songId: songs[1].id, position: 2 },
    { playlistId: driveMix.id, songId: songs[0].id, position: 0 },
    { playlistId: driveMix.id, songId: songs[2].id, position: 1 },
    { playlistId: driveMix.id, songId: songs[6].id, position: 2 }
  ]);

  console.log('[seed] Creating favorites and recently played history...');
  await Favorite.bulkCreate([
    { userId: listener.id, songId: songs[0].id },
    { userId: listener.id, songId: songs[3].id },
    { userId: listener.id, songId: songs[5].id }
  ]);

  const now = Date.now();
  await RecentlyPlayed.bulkCreate(
    [songs[1], songs[4], songs[0], songs[6]].map((s, idx) => ({
      userId: listener.id,
      songId: s.id,
      playedAt: new Date(now - idx * 1000 * 60 * 60)
    }))
  );

  console.log('\n[seed] Done! Sample accounts:');
  console.log('  Admin    -> email: admin@auralis.local     password: Admin123!');
  console.log('  Listener -> email: listener@auralis.local  password: Listener123!\n');

  await sequelize.close();
}

seed().catch((err) => {
  console.error('[seed] Failed:', err);
  process.exit(1);
});
