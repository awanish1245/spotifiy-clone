// config/db.js
// Sets up the Sequelize connection to a local SQLite database file.
// SQLite is used instead of MongoDB to keep local setup dependency-free
// (no external database server required).

const path = require('path');
const fs = require('fs');
const { Sequelize } = require('sequelize');

require('dotenv').config();

const storagePath = process.env.DB_STORAGE || './data/auralis.sqlite';
const resolvedPath = path.resolve(__dirname, '..', storagePath);

// Make sure the folder that will hold the .sqlite file actually exists.
const dataDir = path.dirname(resolvedPath);
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: resolvedPath,
  logging: false, // set to console.log to debug generated SQL
  define: {
    underscored: false,
    timestamps: true
  }
});

// Verifies the connection is alive; called once when the server boots.
async function connectDB() {
  try {
    await sequelize.authenticate();
    console.log(`[db] Connected to SQLite database at ${resolvedPath}`);
  } catch (err) {
    console.error('[db] Unable to connect to the database:', err.message);
    process.exit(1);
  }
}

module.exports = { sequelize, connectDB };
