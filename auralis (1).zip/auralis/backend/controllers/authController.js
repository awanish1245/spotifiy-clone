// controllers/authController.js
const bcrypt = require('bcryptjs');
const { User } = require('../models');
const generateToken = require('../utils/generateToken');

const PUBLIC_ATTRS = { exclude: ['passwordHash'] };

/** POST /api/auth/register */
async function register(req, res, next) {
  try {
    const { username, email, password } = req.body;

    const existing = await User.findOne({
      where: { email }
    });
    if (existing) {
      return res.status(409).json({ message: 'An account with this email already exists.' });
    }

    const existingUsername = await User.findOne({ where: { username } });
    if (existingUsername) {
      return res.status(409).json({ message: 'That username is already taken.' });
    }

    const passwordHash = await bcrypt.hash(password, 10);

    // The very first registered user becomes an admin automatically so the
    // admin panel is reachable out of the box on a fresh install.
    const userCount = await User.count();
    const role = userCount === 0 ? 'admin' : 'user';

    const user = await User.create({ username, email, passwordHash, role });
    const token = generateToken(user);

    const safeUser = await User.findByPk(user.id, { attributes: PUBLIC_ATTRS });
    res.status(201).json({ user: safeUser, token });
  } catch (err) {
    next(err);
  }
}

/** POST /api/auth/login */
async function login(req, res, next) {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ where: { email } });

    if (!user) {
      return res.status(401).json({ message: 'Invalid email or password.' });
    }

    const match = await bcrypt.compare(password, user.passwordHash);
    if (!match) {
      return res.status(401).json({ message: 'Invalid email or password.' });
    }

    const token = generateToken(user);
    const safeUser = await User.findByPk(user.id, { attributes: PUBLIC_ATTRS });
    res.json({ user: safeUser, token });
  } catch (err) {
    next(err);
  }
}

/** GET /api/auth/me - returns the currently authenticated user. */
async function getMe(req, res) {
  res.json({ user: req.user });
}

/**
 * POST /api/auth/logout
 * JWTs are stateless, so "logout" is handled client-side by discarding the
 * token. This endpoint exists so the frontend has a consistent call to make
 * and so a future token-blocklist could be added without changing the API.
 */
function logout(req, res) {
  res.json({ message: 'Logged out successfully.' });
}

module.exports = { register, login, getMe, logout };
