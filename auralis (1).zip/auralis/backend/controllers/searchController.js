// controllers/searchController.js
const { Op } = require('sequelize');
const { Song, Artist, Album } = require('../models');

/**
 * GET /api/search?q=
 * Combined search across songs, artists, and albums for the top search bar.
 * Individual entity search endpoints (/api/songs/search etc.) remain
 * available for more focused lookups.
 */
async function globalSearch(req, res, next) {
  try {
    const q = (req.query.q || '').trim();
    if (!q) {
      return res.json({ songs: [], artists: [], albums: [] });
    }

    const [songs, artists, albums] = await Promise.all([
      Song.findAll({
        where: { title: { [Op.like]: `%${q}%` } },
        include: [
          { model: Artist, attributes: ['id', 'name'] },
          { model: Album, attributes: ['id', 'title', 'coverUrl'] }
        ],
        limit: 10
      }),
      Artist.findAll({ where: { name: { [Op.like]: `%${q}%` } }, limit: 10 }),
      Album.findAll({
        where: { title: { [Op.like]: `%${q}%` } },
        include: [{ model: Artist, attributes: ['id', 'name'] }],
        limit: 10
      })
    ]);

    res.json({ songs, artists, albums });
  } catch (err) {
    next(err);
  }
}

module.exports = { globalSearch };
