// controllers/songController.js
const fs = require('fs');
const path = require('path');
const { Op } = require('sequelize');
const { Song, Artist, Album } = require('../models');
const { SONGS_DIR } = require('../middleware/upload');

const INCLUDE = [
  { model: Artist, attributes: ['id', 'name', 'imageUrl'] },
  { model: Album, attributes: ['id', 'title', 'coverUrl'] }
];

/** GET /api/songs - list songs with pagination, used for "Trending"/browse grids. */
async function listSongs(req, res, next) {
  try {
    const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
    const limit = Math.min(parseInt(req.query.limit, 10) || 20, 100);
    const offset = (page - 1) * limit;

    const sort = req.query.sort === 'trending' ? [['playCount', 'DESC']] : [['createdAt', 'DESC']];

    const { rows, count } = await Song.findAndCountAll({
      include: INCLUDE,
      order: sort,
      limit,
      offset
    });

    res.json({ songs: rows, total: count, page, pages: Math.ceil(count / limit) });
  } catch (err) {
    next(err);
  }
}

/** GET /api/songs/:id */
async function getSong(req, res, next) {
  try {
    const song = await Song.findByPk(req.params.id, { include: INCLUDE });
    if (!song) return res.status(404).json({ message: 'Song not found.' });
    res.json({ song });
  } catch (err) {
    next(err);
  }
}

/** POST /api/songs - create a song with an uploaded audio file (and optional cover). Admin only. */
async function createSong(req, res, next) {
  try {
    const audioFile = req.files && req.files.audio ? req.files.audio[0] : null;
    const coverFile = req.files && req.files.cover ? req.files.cover[0] : null;

    if (!audioFile) {
      return res.status(400).json({ message: 'An audio file is required.' });
    }

    const { title, artistId, albumId, genre, trackNumber, duration } = req.body;

    if (!title || !artistId) {
      return res.status(400).json({ message: 'Title and artistId are required.' });
    }

    const artist = await Artist.findByPk(artistId);
    if (!artist) return res.status(400).json({ message: 'artistId does not match an existing artist.' });

    const song = await Song.create({
      title,
      artistId,
      albumId: albumId || null,
      genre: genre || '',
      trackNumber: trackNumber ? Number(trackNumber) : 1,
      duration: duration ? Number(duration) : 0,
      filePath: `songs/${audioFile.filename}`,
      coverUrl: coverFile ? `/uploads/covers/${coverFile.filename}` : null
    });

    const fullSong = await Song.findByPk(song.id, { include: INCLUDE });
    res.status(201).json({ song: fullSong });
  } catch (err) {
    next(err);
  }
}

/** PUT /api/songs/:id - update song metadata. Admin only. */
async function updateSong(req, res, next) {
  try {
    const song = await Song.findByPk(req.params.id);
    if (!song) return res.status(404).json({ message: 'Song not found.' });

    const { title, artistId, albumId, genre, trackNumber } = req.body;
    if (title !== undefined) song.title = title;
    if (artistId !== undefined) song.artistId = artistId;
    if (albumId !== undefined) song.albumId = albumId || null;
    if (genre !== undefined) song.genre = genre;
    if (trackNumber !== undefined) song.trackNumber = Number(trackNumber);

    await song.save();
    const fullSong = await Song.findByPk(song.id, { include: INCLUDE });
    res.json({ song: fullSong });
  } catch (err) {
    next(err);
  }
}

/** DELETE /api/songs/:id - removes the DB row and the underlying audio file. Admin only. */
async function deleteSong(req, res, next) {
  try {
    const song = await Song.findByPk(req.params.id);
    if (!song) return res.status(404).json({ message: 'Song not found.' });

    const absolutePath = path.join(SONGS_DIR, path.basename(song.filePath));
    fs.unlink(absolutePath, () => {}); // best-effort cleanup, ignore errors

    await song.destroy();
    res.json({ message: 'Song deleted.' });
  } catch (err) {
    next(err);
  }
}

/**
 * GET /api/songs/:id/stream
 * Streams the local MP3/WAV/OGG file with HTTP range support so the
 * HTML5 <audio> element can seek without downloading the whole file.
 */
async function streamSong(req, res, next) {
  try {
    const song = await Song.findByPk(req.params.id);
    if (!song) return res.status(404).json({ message: 'Song not found.' });

    const filePath = path.join(SONGS_DIR, path.basename(song.filePath));
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ message: 'Audio file missing from storage.' });
    }

    const stat = fs.statSync(filePath);
    const fileSize = stat.size;
    const range = req.headers.range;
    const ext = path.extname(filePath).toLowerCase();
    const contentType = ext === '.wav' ? 'audio/wav' : ext === '.ogg' ? 'audio/ogg' : 'audio/mpeg';

    if (range) {
      const [startStr, endStr] = range.replace(/bytes=/, '').split('-');
      const start = parseInt(startStr, 10);
      const end = endStr ? parseInt(endStr, 10) : fileSize - 1;
      const chunkSize = end - start + 1;

      res.writeHead(206, {
        'Content-Range': `bytes ${start}-${end}/${fileSize}`,
        'Accept-Ranges': 'bytes',
        'Content-Length': chunkSize,
        'Content-Type': contentType
      });
      fs.createReadStream(filePath, { start, end }).pipe(res);
    } else {
      res.writeHead(200, {
        'Content-Length': fileSize,
        'Content-Type': contentType,
        'Accept-Ranges': 'bytes'
      });
      fs.createReadStream(filePath).pipe(res);
    }

    // Fire-and-forget play count increment; does not block the stream response.
    Song.increment('playCount', { where: { id: song.id } }).catch(() => {});
  } catch (err) {
    next(err);
  }
}

/** GET /api/songs/search?q= - used by the global search endpoint too. */
async function searchSongs(req, res, next) {
  try {
    const q = (req.query.q || '').trim();
    if (!q) return res.json({ songs: [] });

    const songs = await Song.findAll({
      where: { title: { [Op.like]: `%${q}%` } },
      include: INCLUDE,
      limit: 25
    });
    res.json({ songs });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  listSongs,
  getSong,
  createSong,
  updateSong,
  deleteSong,
  streamSong,
  searchSongs
};
