// controllers/playlistController.js
const { Playlist, PlaylistSong, Song, Artist, Album, User } = require('../models');

const SONG_INCLUDE = [
  { model: Artist, attributes: ['id', 'name'] },
  { model: Album, attributes: ['id', 'title', 'coverUrl'] }
];

async function withOrderedSongs(playlist) {
  const links = await PlaylistSong.findAll({
    where: { playlistId: playlist.id },
    order: [['position', 'ASC']],
    include: [{ model: Song, include: SONG_INCLUDE }]
  });
  const plain = playlist.toJSON();
  plain.songs = links.map((l) => l.Song);
  return plain;
}

/** GET /api/playlists - public playlists plus the current user's own private ones. */
async function listPlaylists(req, res, next) {
  try {
    const where = req.user
      ? { [Playlist.sequelize.Sequelize.Op.or]: [{ isPublic: true }, { ownerId: req.user.id }] }
      : { isPublic: true };

    const playlists = await Playlist.findAll({
      where,
      include: [{ model: User, as: 'owner', attributes: ['id', 'username'] }],
      order: [['updatedAt', 'DESC']]
    });
    res.json({ playlists });
  } catch (err) {
    next(err);
  }
}

/** GET /api/playlists/:id */
async function getPlaylist(req, res, next) {
  try {
    const playlist = await Playlist.findByPk(req.params.id, {
      include: [{ model: User, as: 'owner', attributes: ['id', 'username'] }]
    });
    if (!playlist) return res.status(404).json({ message: 'Playlist not found.' });

    if (!playlist.isPublic && (!req.user || req.user.id !== playlist.ownerId)) {
      return res.status(403).json({ message: 'This playlist is private.' });
    }

    const full = await withOrderedSongs(playlist);
    res.json({ playlist: full });
  } catch (err) {
    next(err);
  }
}

/** POST /api/playlists */
async function createPlaylist(req, res, next) {
  try {
    const { name, description, isPublic } = req.body;
    if (!name) return res.status(400).json({ message: 'Playlist name is required.' });

    const playlist = await Playlist.create({
      name,
      description: description || '',
      isPublic: isPublic === undefined ? true : Boolean(isPublic),
      ownerId: req.user.id
    });

    res.status(201).json({ playlist: await withOrderedSongs(playlist) });
  } catch (err) {
    next(err);
  }
}

async function assertOwnership(req, res) {
  const playlist = await Playlist.findByPk(req.params.id);
  if (!playlist) {
    res.status(404).json({ message: 'Playlist not found.' });
    return null;
  }
  if (playlist.ownerId !== req.user.id && req.user.role !== 'admin') {
    res.status(403).json({ message: 'You do not have permission to modify this playlist.' });
    return null;
  }
  return playlist;
}

/** PUT /api/playlists/:id - rename, redescribe, toggle visibility, or set a cover. */
async function updatePlaylist(req, res, next) {
  try {
    const playlist = await assertOwnership(req, res);
    if (!playlist) return;

    const { name, description, isPublic } = req.body;
    if (name !== undefined) playlist.name = name;
    if (description !== undefined) playlist.description = description;
    if (isPublic !== undefined) playlist.isPublic = Boolean(isPublic);
    if (req.file) playlist.coverUrl = `/uploads/covers/${req.file.filename}`;

    await playlist.save();
    res.json({ playlist: await withOrderedSongs(playlist) });
  } catch (err) {
    next(err);
  }
}

/** DELETE /api/playlists/:id */
async function deletePlaylist(req, res, next) {
  try {
    const playlist = await assertOwnership(req, res);
    if (!playlist) return;
    await playlist.destroy();
    res.json({ message: 'Playlist deleted.' });
  } catch (err) {
    next(err);
  }
}

/** POST /api/playlists/:id/songs - body: { songId } appends a song to the end. */
async function addSong(req, res, next) {
  try {
    const playlist = await assertOwnership(req, res);
    if (!playlist) return;

    const { songId } = req.body;
    const song = await Song.findByPk(songId);
    if (!song) return res.status(400).json({ message: 'songId does not match an existing song.' });

    const existingLink = await PlaylistSong.findOne({ where: { playlistId: playlist.id, songId } });
    if (existingLink) return res.status(409).json({ message: 'That song is already in this playlist.' });

    const count = await PlaylistSong.count({ where: { playlistId: playlist.id } });
    await PlaylistSong.create({ playlistId: playlist.id, songId, position: count });

    res.status(201).json({ playlist: await withOrderedSongs(playlist) });
  } catch (err) {
    next(err);
  }
}

/** DELETE /api/playlists/:id/songs/:songId */
async function removeSong(req, res, next) {
  try {
    const playlist = await assertOwnership(req, res);
    if (!playlist) return;

    await PlaylistSong.destroy({ where: { playlistId: playlist.id, songId: req.params.songId } });

    // Re-sequence remaining positions so there are no gaps.
    const remaining = await PlaylistSong.findAll({
      where: { playlistId: playlist.id },
      order: [['position', 'ASC']]
    });
    await Promise.all(remaining.map((link, idx) => link.update({ position: idx })));

    res.json({ playlist: await withOrderedSongs(playlist) });
  } catch (err) {
    next(err);
  }
}

/** PATCH /api/playlists/:id/reorder - body: { songIds: [...] } full ordered list. */
async function reorderSongs(req, res, next) {
  try {
    const playlist = await assertOwnership(req, res);
    if (!playlist) return;

    const { songIds } = req.body;
    if (!Array.isArray(songIds)) {
      return res.status(400).json({ message: 'songIds must be an array of song IDs.' });
    }

    await Promise.all(
      songIds.map((songId, idx) =>
        PlaylistSong.update(
          { position: idx },
          { where: { playlistId: playlist.id, songId } }
        )
      )
    );

    res.json({ playlist: await withOrderedSongs(playlist) });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  listPlaylists,
  getPlaylist,
  createPlaylist,
  updatePlaylist,
  deletePlaylist,
  addSong,
  removeSong,
  reorderSongs
};
