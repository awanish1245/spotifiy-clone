// controllers/artistController.js
const fs = require('fs');
const path = require('path');
const { Op } = require('sequelize');
const { Artist, Album, Song } = require('../models');
const { COVERS_DIR } = require('../middleware/upload');

/** GET /api/artists */
async function listArtists(req, res, next) {
  try {
    const artists = await Artist.findAll({ order: [['name', 'ASC']] });
    res.json({ artists });
  } catch (err) {
    next(err);
  }
}

/** GET /api/artists/:id - includes their albums and songs for the artist detail page. */
async function getArtist(req, res, next) {
  try {
    const artist = await Artist.findByPk(req.params.id, {
      include: [
        { model: Album },
        { model: Song, include: [{ model: Album, attributes: ['id', 'title', 'coverUrl'] }] }
      ]
    });
    if (!artist) return res.status(404).json({ message: 'Artist not found.' });
    res.json({ artist });
  } catch (err) {
    next(err);
  }
}

/** POST /api/artists - admin only. Accepts optional "image" file. */
async function createArtist(req, res, next) {
  try {
    const { name, bio, genre } = req.body;
    if (!name) return res.status(400).json({ message: 'Artist name is required.' });

    const imageUrl = req.file ? `/uploads/covers/${req.file.filename}` : null;
    const artist = await Artist.create({ name, bio: bio || '', genre: genre || '', imageUrl });
    res.status(201).json({ artist });
  } catch (err) {
    next(err);
  }
}

/** PUT /api/artists/:id - admin only. */
async function updateArtist(req, res, next) {
  try {
    const artist = await Artist.findByPk(req.params.id);
    if (!artist) return res.status(404).json({ message: 'Artist not found.' });

    const { name, bio, genre } = req.body;
    if (name !== undefined) artist.name = name;
    if (bio !== undefined) artist.bio = bio;
    if (genre !== undefined) artist.genre = genre;
    if (req.file) artist.imageUrl = `/uploads/covers/${req.file.filename}`;

    await artist.save();
    res.json({ artist });
  } catch (err) {
    next(err);
  }
}

/** DELETE /api/artists/:id - admin only. Blocks deletion if the artist still has songs. */
async function deleteArtist(req, res, next) {
  try {
    const artist = await Artist.findByPk(req.params.id);
    if (!artist) return res.status(404).json({ message: 'Artist not found.' });

    const songCount = await Song.count({ where: { artistId: artist.id } });
    if (songCount > 0) {
      return res.status(400).json({
        message: `Cannot delete: ${songCount} song(s) still reference this artist. Delete or reassign them first.`
      });
    }

    if (artist.imageUrl) {
      const imgPath = path.join(COVERS_DIR, path.basename(artist.imageUrl));
      fs.unlink(imgPath, () => {});
    }

    await artist.destroy();
    res.json({ message: 'Artist deleted.' });
  } catch (err) {
    next(err);
  }
}

/** GET /api/artists/search?q= */
async function searchArtists(req, res, next) {
  try {
    const q = (req.query.q || '').trim();
    if (!q) return res.json({ artists: [] });
    const artists = await Artist.findAll({
      where: { name: { [Op.like]: `%${q}%` } },
      limit: 25
    });
    res.json({ artists });
  } catch (err) {
    next(err);
  }
}

module.exports = { listArtists, getArtist, createArtist, updateArtist, deleteArtist, searchArtists };
