// controllers/favoriteController.js
const { Favorite, Song, Artist, Album } = require('../models');

const SONG_INCLUDE = [
  { model: Artist, attributes: ['id', 'name'] },
  { model: Album, attributes: ['id', 'title', 'coverUrl'] }
];

/** GET /api/favorites - the current user's liked songs, most recently liked first. */
async function listFavorites(req, res, next) {
  try {
    const favorites = await Favorite.findAll({
      where: { userId: req.user.id },
      include: [{ model: Song, include: SONG_INCLUDE }],
      order: [['createdAt', 'DESC']]
    });
    res.json({ songs: favorites.map((f) => f.Song) });
  } catch (err) {
    next(err);
  }
}

/** POST /api/favorites - body: { songId } */
async function addFavorite(req, res, next) {
  try {
    const { songId } = req.body;
    const song = await Song.findByPk(songId);
    if (!song) return res.status(400).json({ message: 'songId does not match an existing song.' });

    const [favorite, created] = await Favorite.findOrCreate({
      where: { userId: req.user.id, songId },
      defaults: { userId: req.user.id, songId }
    });

    res.status(created ? 201 : 200).json({ message: created ? 'Added to favorites.' : 'Already a favorite.' });
  } catch (err) {
    next(err);
  }
}

/** DELETE /api/favorites/:songId */
async function removeFavorite(req, res, next) {
  try {
    await Favorite.destroy({ where: { userId: req.user.id, songId: req.params.songId } });
    res.json({ message: 'Removed from favorites.' });
  } catch (err) {
    next(err);
  }
}

module.exports = { listFavorites, addFavorite, removeFavorite };
