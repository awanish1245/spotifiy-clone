// controllers/adminController.js
// User management actions exposed only to admins via the admin dashboard.
// Song/album/artist management reuse the same controllers as the public
// API (they are simply mounted behind requireAdmin for write operations).

const { User, Playlist, Song } = require('../models');

/** GET /api/admin/users */
async function listUsers(req, res, next) {
  try {
    const users = await User.findAll({
      attributes: { exclude: ['passwordHash'] },
      order: [['createdAt', 'DESC']]
    });
    res.json({ users });
  } catch (err) {
    next(err);
  }
}

/** PUT /api/admin/users/:id/role - body: { role: 'admin' | 'user' } */
async function setUserRole(req, res, next) {
  try {
    const { role } = req.body;
    if (!['admin', 'user'].includes(role)) {
      return res.status(400).json({ message: "role must be 'admin' or 'user'." });
    }

    const user = await User.findByPk(req.params.id);
    if (!user) return res.status(404).json({ message: 'User not found.' });

    user.role = role;
    await user.save();

    const safeUser = await User.findByPk(user.id, { attributes: { exclude: ['passwordHash'] } });
    res.json({ user: safeUser });
  } catch (err) {
    next(err);
  }
}

/** DELETE /api/admin/users/:id */
async function deleteUser(req, res, next) {
  try {
    const user = await User.findByPk(req.params.id);
    if (!user) return res.status(404).json({ message: 'User not found.' });

    if (user.id === req.user.id) {
      return res.status(400).json({ message: 'You cannot delete your own account while logged in as it.' });
    }

    await user.destroy();
    res.json({ message: 'User deleted.' });
  } catch (err) {
    next(err);
  }
}

/** GET /api/admin/stats - simple counts for the admin dashboard overview cards. */
async function getStats(req, res, next) {
  try {
    const [userCount, songCount, playlistCount] = await Promise.all([
      User.count(),
      Song.count(),
      Playlist.count()
    ]);
    res.json({ users: userCount, songs: songCount, playlists: playlistCount });
  } catch (err) {
    next(err);
  }
}

module.exports = { listUsers, setUserRole, deleteUser, getStats };
