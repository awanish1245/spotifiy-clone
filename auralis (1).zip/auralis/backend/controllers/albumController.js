// controllers/albumController.js
const fs = require('fs');
const path = require('path');
const { Op } = require('sequelize');
const { Album, Artist, Song } = require('../models');
const { COVERS_DIR } = require('../middleware/upload');

/** GET /api/albums */
async function listAlbums(req, res, next) {
  try {
    const albums = await Album.findAll({
      include: [{ model: Artist, attributes: ['id', 'name'] }],
      order: [['createdAt', 'DESC']]
    });
    res.json({ albums });
  } catch (err) {
    next(err);
  }
}

/** GET /api/albums/:id - includes track listing. */
async function getAlbum(req, res, next) {
  try {
    const album = await Album.findByPk(req.params.id, {
      include: [
        { model: Artist, attributes: ['id', 'name', 'imageUrl'] },
        { model: Song, separate: true, order: [['trackNumber', 'ASC']] }
      ]
    });
    if (!album) return res.status(404).json({ message: 'Album not found.' });
    res.json({ album });
  } catch (err) {
    next(err);
  }
}

/** POST /api/albums - admin only. Accepts optional "cover" file. */
async function createAlbum(req, res, next) {
  try {
    const { title, artistId, releaseYear, genre } = req.body;
    if (!title || !artistId) {
      return res.status(400).json({ message: 'title and artistId are required.' });
    }

    const artist = await Artist.findByPk(artistId);
    if (!artist) return res.status(400).json({ message: 'artistId does not match an existing artist.' });

    const coverUrl = req.file ? `/uploads/covers/${req.file.filename}` : null;
    const album = await Album.create({
      title,
      artistId,
      releaseYear: releaseYear ? Number(releaseYear) : null,
      genre: genre || '',
      coverUrl
    });

    const fullAlbum = await Album.findByPk(album.id, { include: [Artist] });
    res.status(201).json({ album: fullAlbum });
  } catch (err) {
    next(err);
  }
}

/** PUT /api/albums/:id - admin only. */
async function updateAlbum(req, res, next) {
  try {
    const album = await Album.findByPk(req.params.id);
    if (!album) return res.status(404).json({ message: 'Album not found.' });

    const { title, artistId, releaseYear, genre } = req.body;
    if (title !== undefined) album.title = title;
    if (artistId !== undefined) album.artistId = artistId;
    if (releaseYear !== undefined) album.releaseYear = Number(releaseYear);
    if (genre !== undefined) album.genre = genre;
    if (req.file) album.coverUrl = `/uploads/covers/${req.file.filename}`;

    await album.save();
    res.json({ album });
  } catch (err) {
    next(err);
  }
}

/** DELETE /api/albums/:id - admin only. */
async function deleteAlbum(req, res, next) {
  try {
    const album = await Album.findByPk(req.params.id);
    if (!album) return res.status(404).json({ message: 'Album not found.' });

    // Detach songs rather than deleting them outright, preserving the audio library.
    await Song.update({ albumId: null }, { where: { albumId: album.id } });

    if (album.coverUrl) {
      const imgPath = path.join(COVERS_DIR, path.basename(album.coverUrl));
      fs.unlink(imgPath, () => {});
    }

    await album.destroy();
    res.json({ message: 'Album deleted. Its songs were kept and unlinked from the album.' });
  } catch (err) {
    next(err);
  }
}

/** GET /api/albums/search?q= */
async function searchAlbums(req, res, next) {
  try {
    const q = (req.query.q || '').trim();
    if (!q) return res.json({ albums: [] });
    const albums = await Album.findAll({
      where: { title: { [Op.like]: `%${q}%` } },
      include: [{ model: Artist, attributes: ['id', 'name'] }],
      limit: 25
    });
    res.json({ albums });
  } catch (err) {
    next(err);
  }
}

module.exports = { listAlbums, getAlbum, createAlbum, updateAlbum, deleteAlbum, searchAlbums };
