// controllers/historyController.js
const { RecentlyPlayed, Song, Artist, Album } = require('../models');

const SONG_INCLUDE = [
  { model: Artist, attributes: ['id', 'name'] },
  { model: Album, attributes: ['id', 'title', 'coverUrl'] }
];

/**
 * GET /api/history/recent - de-duplicated list of the user's most
 * recently played songs (used for the "Recently Played" shelf).
 */
async function getRecentlyPlayed(req, res, next) {
  try {
    const entries = await RecentlyPlayed.findAll({
      where: { userId: req.user.id },
      order: [['playedAt', 'DESC']],
      limit: 100,
      include: [{ model: Song, include: SONG_INCLUDE }]
    });

    const seen = new Set();
    const deduped = [];
    for (const entry of entries) {
      if (!entry.Song || seen.has(entry.Song.id)) continue;
      seen.add(entry.Song.id);
      deduped.push(entry.Song);
      if (deduped.length >= 20) break;
    }

    res.json({ songs: deduped });
  } catch (err) {
    next(err);
  }
}

/** GET /api/history/full - the complete, non-deduplicated listening history (paginated). */
async function getFullHistory(req, res, next) {
  try {
    const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
    const limit = Math.min(parseInt(req.query.limit, 10) || 30, 100);
    const offset = (page - 1) * limit;

    const { rows, count } = await RecentlyPlayed.findAndCountAll({
      where: { userId: req.user.id },
      order: [['playedAt', 'DESC']],
      limit,
      offset,
      include: [{ model: Song, include: SONG_INCLUDE }]
    });

    res.json({ history: rows, total: count, page, pages: Math.ceil(count / limit) });
  } catch (err) {
    next(err);
  }
}

/** POST /api/history - body: { songId }. Logs a playback event ("continue listening" support). */
async function logPlay(req, res, next) {
  try {
    const { songId } = req.body;
    const song = await Song.findByPk(songId);
    if (!song) return res.status(400).json({ message: 'songId does not match an existing song.' });

    await RecentlyPlayed.create({ userId: req.user.id, songId, playedAt: new Date() });
    res.status(201).json({ message: 'Play logged.' });
  } catch (err) {
    next(err);
  }
}

module.exports = { getRecentlyPlayed, getFullHistory, logPlay };
