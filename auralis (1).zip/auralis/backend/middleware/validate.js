// middleware/validate.js
const { validationResult } = require('express-validator');

/** Runs after express-validator checks; returns a 400 with details if any failed. */
function validate(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      message: 'Validation failed.',
      details: errors.array().map((e) => e.msg)
    });
  }
  next();
}

module.exports = validate;
