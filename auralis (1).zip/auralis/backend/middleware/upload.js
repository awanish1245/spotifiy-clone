// middleware/upload.js
// Configures Multer storage/filters for the two kinds of files the app
// accepts: audio files (mp3/wav/ogg) and cover images (jpg/png/webp).

const fs = require('fs');
const path = require('path');
const multer = require('multer');

const SONGS_DIR = path.join(__dirname, '..', 'uploads', 'songs');
const COVERS_DIR = path.join(__dirname, '..', 'uploads', 'covers');

[SONGS_DIR, COVERS_DIR].forEach((dir) => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

function safeFilename(originalName) {
  const ext = path.extname(originalName).toLowerCase();
  const base = path
    .basename(originalName, ext)
    .replace(/[^a-z0-9-_]/gi, '_')
    .slice(0, 60);
  const unique = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
  return `${base}-${unique}${ext}`;
}

const audioStorage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, SONGS_DIR),
  filename: (req, file, cb) => cb(null, safeFilename(file.originalname))
});

const imageStorage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, COVERS_DIR),
  filename: (req, file, cb) => cb(null, safeFilename(file.originalname))
});

const AUDIO_TYPES = new Set(['audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/ogg', 'audio/x-wav']);
const IMAGE_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp']);

function audioFileFilter(req, file, cb) {
  if (!AUDIO_TYPES.has(file.mimetype)) {
    return cb(new Error('Only MP3, WAV, or OGG audio files are allowed.'));
  }
  cb(null, true);
}

function imageFileFilter(req, file, cb) {
  if (!IMAGE_TYPES.has(file.mimetype)) {
    return cb(new Error('Only JPEG, PNG, or WEBP images are allowed.'));
  }
  cb(null, true);
}

const uploadAudio = multer({
  storage: audioStorage,
  fileFilter: audioFileFilter,
  limits: { fileSize: Number(process.env.MAX_AUDIO_UPLOAD_BYTES) || 26214400 }
});

const uploadImage = multer({
  storage: imageStorage,
  fileFilter: imageFileFilter,
  limits: { fileSize: Number(process.env.MAX_IMAGE_UPLOAD_BYTES) || 5242880 }
});

// Combined uploader for the "create song" endpoint, which accepts an
// audio file field and an optional cover image field in one request.
const uploadSongWithCover = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      const dir = file.fieldname === 'cover' ? COVERS_DIR : SONGS_DIR;
      cb(null, dir);
    },
    filename: (req, file, cb) => cb(null, safeFilename(file.originalname))
  }),
  fileFilter: (req, file, cb) => {
    if (file.fieldname === 'audio') return audioFileFilter(req, file, cb);
    if (file.fieldname === 'cover') return imageFileFilter(req, file, cb);
    cb(new Error('Unexpected file field.'));
  },
  limits: { fileSize: Number(process.env.MAX_AUDIO_UPLOAD_BYTES) || 26214400 }
});

module.exports = {
  uploadAudio,
  uploadImage,
  uploadSongWithCover,
  SONGS_DIR,
  COVERS_DIR
};
