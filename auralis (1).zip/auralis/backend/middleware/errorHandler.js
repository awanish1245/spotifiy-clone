// middleware/errorHandler.js
const multer = require('multer');

/** 404 handler for unmatched routes - always placed just before the error handler. */
function notFound(req, res, next) {
  res.status(404).json({ message: `Route not found: ${req.method} ${req.originalUrl}` });
}

/** Centralized error handler. Normalizes Multer, Sequelize, and generic errors. */
// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  console.error('[error]', err.message);

  if (err instanceof multer.MulterError) {
    return res.status(400).json({ message: `Upload error: ${err.message}` });
  }

  if (err.name === 'SequelizeValidationError' || err.name === 'SequelizeUniqueConstraintError') {
    const details = err.errors ? err.errors.map((e) => e.message) : [err.message];
    return res.status(400).json({ message: 'Validation failed.', details });
  }

  if (err.message && err.message.includes('allowed')) {
    // File-type errors thrown from the upload middleware filters.
    return res.status(400).json({ message: err.message });
  }

  const status = err.status || 500;
  res.status(status).json({
    message: status === 500 ? 'Something went wrong on the server.' : err.message
  });
}

module.exports = { notFound, errorHandler };
