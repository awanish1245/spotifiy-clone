// middleware/auth.js
const jwt = require('jsonwebtoken');
const { User } = require('../models');

/**
 * Verifies the Bearer JWT on the Authorization header and attaches the
 * corresponding user (minus the password hash) to req.user.
 */
async function requireAuth(req, res, next) {
  try {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;

    if (!token) {
      return res.status(401).json({ message: 'Authentication required. Please log in.' });
    }

    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findByPk(payload.id, {
      attributes: { exclude: ['passwordHash'] }
    });

    if (!user) {
      return res.status(401).json({ message: 'The account for this token no longer exists.' });
    }

    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Invalid or expired session. Please log in again.' });
  }
}

/**
 * Optional auth: attaches req.user if a valid token is present, but never
 * blocks the request. Useful for endpoints like search that behave the
 * same for guests and logged-in users.
 */
async function optionalAuth(req, res, next) {
  try {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return next();

    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findByPk(payload.id, {
      attributes: { exclude: ['passwordHash'] }
    });
    if (user) req.user = user;
  } catch (err) {
    // ignore invalid tokens for optional auth
  }
  next();
}

/** Restricts a route to users with the "admin" role. */
function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Admin privileges are required for this action.' });
  }
  next();
}

module.exports = { requireAuth, optionalAuth, requireAdmin };
