// utils/generateToken.js
const jwt = require('jsonwebtoken');

/** Signs a JWT containing the user's id and role. */
function generateToken(user) {
  return jwt.sign(
    { id: user.id, role: user.role },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
}

module.exports = generateToken;
