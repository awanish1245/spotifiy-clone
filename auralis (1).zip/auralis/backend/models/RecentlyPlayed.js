// models/RecentlyPlayed.js
// One row per playback event, used to build "Recently Played" and
// "Listening History" views. Not unique per song, so history accumulates.
const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db');

const RecentlyPlayed = sequelize.define('RecentlyPlayed', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  playedAt: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  }
});

module.exports = RecentlyPlayed;
