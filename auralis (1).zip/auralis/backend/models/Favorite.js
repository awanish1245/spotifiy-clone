// models/Favorite.js
// Represents a single user's "liked" song. Uniqueness of (userId, songId)
// is enforced in models/index.js via a composite unique index.
const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db');

const Favorite = sequelize.define('Favorite', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  }
});

module.exports = Favorite;
