// models/index.js
// Central place where all model associations (foreign keys) are declared.
// Import this file once (from server.js) before the models are used anywhere else.

const { sequelize } = require('../config/db');
const User = require('./User');
const Artist = require('./Artist');
const Album = require('./Album');
const Song = require('./Song');
const Playlist = require('./Playlist');
const PlaylistSong = require('./PlaylistSong');
const Favorite = require('./Favorite');
const RecentlyPlayed = require('./RecentlyPlayed');

// ---- Artist <-> Album ----
Artist.hasMany(Album, { foreignKey: 'artistId', onDelete: 'CASCADE' });
Album.belongsTo(Artist, { foreignKey: 'artistId' });

// ---- Artist <-> Song (a song always has a primary artist) ----
Artist.hasMany(Song, { foreignKey: 'artistId', onDelete: 'CASCADE' });
Song.belongsTo(Artist, { foreignKey: 'artistId' });

// ---- Album <-> Song ----
Album.hasMany(Song, { foreignKey: 'albumId', onDelete: 'SET NULL' });
Song.belongsTo(Album, { foreignKey: 'albumId' });

// ---- User <-> Playlist ----
User.hasMany(Playlist, { foreignKey: 'ownerId', onDelete: 'CASCADE' });
Playlist.belongsTo(User, { foreignKey: 'ownerId', as: 'owner' });

// ---- Playlist <-> Song (many-to-many through PlaylistSong) ----
Playlist.belongsToMany(Song, { through: PlaylistSong, foreignKey: 'playlistId', otherKey: 'songId' });
Song.belongsToMany(Playlist, { through: PlaylistSong, foreignKey: 'songId', otherKey: 'playlistId' });
Playlist.hasMany(PlaylistSong, { foreignKey: 'playlistId', onDelete: 'CASCADE' });
PlaylistSong.belongsTo(Playlist, { foreignKey: 'playlistId' });
Song.hasMany(PlaylistSong, { foreignKey: 'songId', onDelete: 'CASCADE' });
PlaylistSong.belongsTo(Song, { foreignKey: 'songId' });

// ---- User <-> Song (favorites, many-to-many) ----
User.belongsToMany(Song, { through: Favorite, foreignKey: 'userId', otherKey: 'songId', as: 'favoriteSongs' });
Song.belongsToMany(User, { through: Favorite, foreignKey: 'songId', otherKey: 'userId', as: 'favoritedBy' });
User.hasMany(Favorite, { foreignKey: 'userId', onDelete: 'CASCADE' });
Favorite.belongsTo(Song, { foreignKey: 'songId' });
Favorite.belongsTo(User, { foreignKey: 'userId' });

// ---- User <-> Song (recently played / history) ----
User.hasMany(RecentlyPlayed, { foreignKey: 'userId', onDelete: 'CASCADE' });
RecentlyPlayed.belongsTo(User, { foreignKey: 'userId' });
Song.hasMany(RecentlyPlayed, { foreignKey: 'songId', onDelete: 'CASCADE' });
RecentlyPlayed.belongsTo(Song, { foreignKey: 'songId' });

// Prevent a user from favoriting the same song twice at the database level.
Favorite.addHook('beforeValidate', () => {});

/**
 * Creates all tables (and the composite unique index used by Favorite)
 * if they do not already exist. Called once on server startup.
 */
async function syncModels() {
  await sequelize.sync(); // non-destructive: only creates missing tables/columns
  // Composite uniqueness: a user can only favorite a given song once.
  const queryInterface = sequelize.getQueryInterface();
  try {
    await queryInterface.addIndex('Favorites', ['userId', 'songId'], {
      unique: true,
      name: 'unique_user_song_favorite'
    });
  } catch (err) {
    // Index likely already exists - safe to ignore.
  }
}

module.exports = {
  sequelize,
  User,
  Artist,
  Album,
  Song,
  Playlist,
  PlaylistSong,
  Favorite,
  RecentlyPlayed,
  syncModels
};
