// models/Playlist.js
const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db');

const Playlist = sequelize.define('Playlist', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  description: {
    type: DataTypes.TEXT,
    defaultValue: ''
  },
  coverUrl: {
    type: DataTypes.STRING,
    defaultValue: null
  },
  isPublic: {
    type: DataTypes.BOOLEAN,
    defaultValue: true
  }
  // ownerId foreign key added via association in models/index.js
});

module.exports = Playlist;
