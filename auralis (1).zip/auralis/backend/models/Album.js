// models/Album.js
const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db');

const Album = sequelize.define('Album', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  title: {
    type: DataTypes.STRING,
    allowNull: false
  },
  coverUrl: {
    type: DataTypes.STRING,
    defaultValue: null
  },
  releaseYear: {
    type: DataTypes.INTEGER,
    defaultValue: null
  },
  genre: {
    type: DataTypes.STRING,
    defaultValue: ''
  }
  // artistId foreign key is added via association in models/index.js
});

module.exports = Album;
