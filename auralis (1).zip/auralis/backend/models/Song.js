// models/Song.js
const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db');

const Song = sequelize.define('Song', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  title: {
    type: DataTypes.STRING,
    allowNull: false
  },
  duration: {
    // duration in seconds, populated on upload
    type: DataTypes.FLOAT,
    defaultValue: 0
  },
  filePath: {
    // relative path under /uploads/songs used for streaming
    type: DataTypes.STRING,
    allowNull: false
  },
  coverUrl: {
    // optional per-song cover; falls back to album cover if absent
    type: DataTypes.STRING,
    defaultValue: null
  },
  genre: {
    type: DataTypes.STRING,
    defaultValue: ''
  },
  trackNumber: {
    type: DataTypes.INTEGER,
    defaultValue: 1
  },
  playCount: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  }
  // artistId and albumId foreign keys are added via association in models/index.js
});

module.exports = Song;
