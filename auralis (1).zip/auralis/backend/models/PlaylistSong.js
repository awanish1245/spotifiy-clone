// models/PlaylistSong.js
// Join table between Playlist and Song, storing the position of each
// song within a playlist so custom ordering can be preserved.
const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db');

const PlaylistSong = sequelize.define('PlaylistSong', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  position: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  }
});

module.exports = PlaylistSong;
