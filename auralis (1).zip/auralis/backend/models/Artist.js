// models/Artist.js
const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db');

const Artist = sequelize.define('Artist', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  bio: {
    type: DataTypes.TEXT,
    defaultValue: ''
  },
  imageUrl: {
    type: DataTypes.STRING,
    defaultValue: null
  },
  genre: {
    type: DataTypes.STRING,
    defaultValue: ''
  }
});

module.exports = Artist;
