// routes/artists.js
const express = require('express');
const {
  listArtists,
  getArtist,
  createArtist,
  updateArtist,
  deleteArtist,
  searchArtists
} = require('../controllers/artistController');
const { requireAuth, requireAdmin } = require('../middleware/auth');
const { uploadImage } = require('../middleware/upload');

const router = express.Router();

router.get('/', listArtists);
router.get('/search', searchArtists);
router.get('/:id', getArtist);

router.post('/', requireAuth, requireAdmin, uploadImage.single('image'), createArtist);
router.put('/:id', requireAuth, requireAdmin, uploadImage.single('image'), updateArtist);
router.delete('/:id', requireAuth, requireAdmin, deleteArtist);

module.exports = router;
