// routes/admin.js
const express = require('express');
const { listUsers, setUserRole, deleteUser, getStats } = require('../controllers/adminController');
const { requireAuth, requireAdmin } = require('../middleware/auth');

const router = express.Router();

router.use(requireAuth, requireAdmin);
router.get('/stats', getStats);
router.get('/users', listUsers);
router.put('/users/:id/role', setUserRole);
router.delete('/users/:id', deleteUser);

module.exports = router;
