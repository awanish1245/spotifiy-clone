// routes/favorites.js
const express = require('express');
const { listFavorites, addFavorite, removeFavorite } = require('../controllers/favoriteController');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

router.use(requireAuth);
router.get('/', listFavorites);
router.post('/', addFavorite);
router.delete('/:songId', removeFavorite);

module.exports = router;
