// routes/playlists.js
const express = require('express');
const {
  listPlaylists,
  getPlaylist,
  createPlaylist,
  updatePlaylist,
  deletePlaylist,
  addSong,
  removeSong,
  reorderSongs
} = require('../controllers/playlistController');
const { requireAuth, optionalAuth } = require('../middleware/auth');
const { uploadImage } = require('../middleware/upload');

const router = express.Router();

router.get('/', optionalAuth, listPlaylists);
router.get('/:id', optionalAuth, getPlaylist);

router.post('/', requireAuth, createPlaylist);
router.put('/:id', requireAuth, uploadImage.single('cover'), updatePlaylist);
router.delete('/:id', requireAuth, deletePlaylist);

router.post('/:id/songs', requireAuth, addSong);
router.delete('/:id/songs/:songId', requireAuth, removeSong);
router.patch('/:id/reorder', requireAuth, reorderSongs);

module.exports = router;
