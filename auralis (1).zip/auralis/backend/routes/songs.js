// routes/songs.js
const express = require('express');
const {
  listSongs,
  getSong,
  createSong,
  updateSong,
  deleteSong,
  streamSong,
  searchSongs
} = require('../controllers/songController');
const { requireAuth, requireAdmin, optionalAuth } = require('../middleware/auth');
const { uploadSongWithCover } = require('../middleware/upload');

const router = express.Router();

router.get('/', optionalAuth, listSongs);
router.get('/search', searchSongs);
router.get('/:id', getSong);
router.get('/:id/stream', streamSong);

router.post(
  '/',
  requireAuth,
  requireAdmin,
  uploadSongWithCover.fields([{ name: 'audio', maxCount: 1 }, { name: 'cover', maxCount: 1 }]),
  createSong
);
router.put('/:id', requireAuth, requireAdmin, updateSong);
router.delete('/:id', requireAuth, requireAdmin, deleteSong);

module.exports = router;
