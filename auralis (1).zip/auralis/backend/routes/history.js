// routes/history.js
const express = require('express');
const { getRecentlyPlayed, getFullHistory, logPlay } = require('../controllers/historyController');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

router.use(requireAuth);
router.get('/recent', getRecentlyPlayed);
router.get('/full', getFullHistory);
router.post('/', logPlay);

module.exports = router;
