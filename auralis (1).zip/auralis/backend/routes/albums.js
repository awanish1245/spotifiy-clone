// routes/albums.js
const express = require('express');
const {
  listAlbums,
  getAlbum,
  createAlbum,
  updateAlbum,
  deleteAlbum,
  searchAlbums
} = require('../controllers/albumController');
const { requireAuth, requireAdmin } = require('../middleware/auth');
const { uploadImage } = require('../middleware/upload');

const router = express.Router();

router.get('/', listAlbums);
router.get('/search', searchAlbums);
router.get('/:id', getAlbum);

router.post('/', requireAuth, requireAdmin, uploadImage.single('cover'), createAlbum);
router.put('/:id', requireAuth, requireAdmin, uploadImage.single('cover'), updateAlbum);
router.delete('/:id', requireAuth, requireAdmin, deleteAlbum);

module.exports = router;
