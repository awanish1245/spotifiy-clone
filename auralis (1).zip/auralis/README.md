# Auralis 🎧

A fully original, self-hosted music streaming web app — built from scratch with **Express, SQLite (via Sequelize), and vanilla HTML/CSS/JS.** No frameworks required on the frontend, no external database server to install, no Spotify code, branding, assets, or APIs of any kind.

> **Important:** Auralis is a platform for streaming *your own* audio files (original recordings, royalty-free tracks, or music you have the rights to use). It does not include, bypass, or interact with Spotify or any other streaming service, and it includes no DRM-circumvention functionality of any kind. See [Sample Audio](#sample-audio--copyright-note) below.

![status](https://img.shields.io/badge/status-fully%20functional-33f5d0)

---

## Features

**Listening experience**
- Dark, aurora-themed UI with an audio-reactive waveform visualizer in the player bar (built on the Web Audio `AnalyserNode`)
- Home feed: Recently Played, Trending, Albums, Artists, Recommended
- Full-text search across songs/artists/albums with live results
- Library browser with infinite scroll (lazy-loaded pages)
- Playlists: create, rename, describe, make public/private, reorder, delete
- Favorites ("liked songs")
- Recently played + full listening history
- Bottom player: play/pause, previous/next, shuffle, repeat (off/all/one), seek bar, volume + mute, playback speed (0.75x–2x), keyboard shortcuts, Media Session integration (lock-screen / OS media controls)
- Toasts, modals, skeleton loading states, fully responsive (desktop/tablet/mobile)

**Backend**
- REST API (Express) covering songs, albums, artists, playlists, favorites, history, search, and admin
- JWT authentication with bcrypt password hashing
- Local file uploads (audio + cover art) via Multer
- HTTP range-request audio streaming (proper seeking support)
- SQLite database via Sequelize ORM — zero external services to install

**Admin dashboard** (`/admin.html`, first registered user is auto-promoted to admin)
- Upload songs (with cover art), edit/delete
- Manage albums, artists, playlists
- Manage users (promote/demote, delete)
- Library stats overview

---

## Project structure

```
auralis/
├── backend/
│   ├── config/db.js              # Sequelize + SQLite connection
│   ├── controllers/               # Route handler logic
│   ├── middleware/                # auth (JWT), upload (Multer), error handling, validation
│   ├── models/                    # Sequelize models + associations (models/index.js)
│   ├── routes/                    # Express routers, one per resource
│   ├── seed/
│   │   ├── generateSampleAudio.js # Generates original placeholder WAV tracks
│   │   ├── generateSampleCovers.js# Generates original placeholder SVG cover art
│   │   └── seed.js                # Populates the DB with sample users/artists/albums/songs/playlists
│   ├── uploads/
│   │   ├── songs/                 # Uploaded + generated audio files live here
│   │   └── covers/                # Uploaded + generated cover art lives here
│   ├── .env.example
│   ├── package.json
│   └── server.js                  # Entry point
├── frontend/
│   └── public/
│       ├── index.html             # Main app shell (SPA)
│       ├── admin.html             # Admin dashboard shell
│       ├── css/style.css          # Main design system + layout
│       ├── css/admin.css          # Admin-only layout additions
│       └── js/
│           ├── api.js             # Fetch wrapper around the REST API
│           ├── player.js          # Audio engine: queue, shuffle/repeat, visualizer, Media Session
│           ├── app.js             # Views, rendering, modals, toasts
│           └── admin.js           # Admin dashboard logic
├── docs/API.md                    # Full API reference
├── package.json                   # Root convenience scripts
└── README.md
```

The Express server serves the frontend's static files directly (`frontend/public`), so the whole app runs from a single `npm start` — no separate frontend build step or dev server.

---

## Installation

**Requirements:** Node.js 18+ and npm. No database server to install — SQLite is a single file created automatically.

```bash
# 1. Clone / unzip the project, then:
cd auralis/backend
cp .env.example .env          # adjust JWT_SECRET etc. if you like
npm install
```

`npm install` compiles the native `sqlite3` driver for your platform, which requires a working C++ toolchain (already present on most systems; on a fresh Linux box you may need `build-essential` and `python3`, on macOS you may need Xcode Command Line Tools). This is a one-time step.

### Sample data (recommended for first run)

```bash
npm run seed
```

This will:
- Create two accounts: an **admin** (`admin@auralis.local` / `Admin123!`) and a regular **listener** (`listener@auralis.local` / `Listener123!`)
- Generate 8 short original placeholder audio tracks (see note below) and original gradient cover art
- Populate 4 artists, 4 albums, 8 songs, 2 playlists, some favorites, and playback history

### Run it

```bash
npm start          # production mode
# or
npm run dev         # nodemon, auto-restarts on file changes
```

Then open **http://localhost:5000**. Log in with one of the seeded accounts above, or register a new one (the very first account ever registered on a fresh database becomes an admin automatically).

Visit **http://localhost:5000/admin.html** for the admin dashboard (admin accounts only).

### Running from the repo root instead

A convenience `package.json` at the project root proxies the same commands:

```bash
npm run install:backend
npm run seed
npm start
```

---

## Configuration (`backend/.env`)

| Variable | Default | Description |
|---|---|---|
| `PORT` | `5000` | Port the server listens on |
| `DB_STORAGE` | `./data/auralis.sqlite` | Path to the SQLite file (auto-created) |
| `JWT_SECRET` | *(change me)* | Signing secret for auth tokens — use a long random string in production |
| `JWT_EXPIRES_IN` | `7d` | Token lifetime |
| `MAX_AUDIO_UPLOAD_BYTES` | `26214400` (25MB) | Max upload size per audio file |
| `MAX_IMAGE_UPLOAD_BYTES` | `5242880` (5MB) | Max upload size per cover image |
| `CORS_ORIGIN` | `*` | Allowed CORS origin(s) |

---

## Sample audio & copyright note

This project does **not** bundle any real songs, since doing so would risk copyright infringement, and no license to any commercial music is included or implied.

Instead, `npm run seed` **synthesizes** a handful of short original placeholder tracks at install time (simple sine-wave chord progressions, written directly to WAV — see `backend/seed/generateSampleAudio.js`). They exist purely so the app is playable immediately after setup. Cover art is likewise generated as simple original gradient SVGs (`backend/seed/generateSampleCovers.js`) — no third-party artwork is used anywhere.

**To use your own music:** log in as an admin, go to `/admin.html` → **Songs** → **Upload song**, and upload any MP3/WAV/OGG files you own the rights to (your own recordings, royalty-free libraries, Creative-Commons-licensed tracks, etc.). Uploaded files are stored under `backend/uploads/songs/` and streamed locally — nothing is sent to or fetched from Spotify or any other third-party service.

---

## API documentation

See [`docs/API.md`](./docs/API.md) for the full REST endpoint reference (routes, required auth, request/response shapes, error format).

---

## Keyboard shortcuts

| Key | Action |
|---|---|
| `Space` | Play / pause |
| `Ctrl + →` / `Ctrl + ←` | Next / previous track |
| `→` / `←` | Seek forward / back 5s |
| `M` | Mute / unmute |
| `S` | Toggle shuffle |
| `R` | Cycle repeat mode (off → all → one) |

---

## Tech stack

- **Backend:** Node.js, Express, Sequelize, SQLite, JWT (`jsonwebtoken`), `bcryptjs`, Multer, `express-validator`
- **Frontend:** Vanilla HTML/CSS/JS (no build step), HTML5 `<audio>`, Web Audio API (`AnalyserNode` for the visualizer), Media Session API
- **Database:** SQLite (file-based; swap the Sequelize dialect for Postgres/MySQL/MongoDB+Mongoose later if you outgrow it — the controllers are written against plain JS objects so the swap is mostly in `models/`)

---

## Notes on originality & scope

- All UI design, copy, iconography (hand-drawn inline SVGs), color palette, and code in this repository were written from scratch for this project.
- No Spotify source code, trademarks, logos, or proprietary APIs are used anywhere in this project.
- No DRM, subscription-bypass, or ad-blocking logic of any kind is implemented — this is a standalone app for your own licensed/original audio.
