# Auralis API Reference

Base URL (local dev): `http://localhost:5000/api`

All request/response bodies are JSON unless noted otherwise (file uploads use `multipart/form-data`). Authenticated routes expect:

```
Authorization: Bearer <jwt>
```

The token is returned from `/auth/login` and `/auth/register`.

---

## Auth

### POST /auth/register
Body: `{ "username": "string(3-30)", "email": "string", "password": "string(6+)" }`
Response `201`: `{ user, token }`
Note: the very first user ever registered is automatically made an `admin`.

### POST /auth/login
Body: `{ "email": "string", "password": "string" }`
Response `200`: `{ user, token }`

### GET /auth/me
Auth required. Response: `{ user }`

### POST /auth/logout
Auth required. Stateless (JWT discarded client-side). Response: `{ message }`

---

## Songs

### GET /songs?page=1&limit=20&sort=trending
Public. `sort=trending` orders by play count descending; omit for newest first.
Response: `{ songs: [...], total, page, pages }`

### GET /songs/search?q=
Public. Response: `{ songs: [...] }`

### GET /songs/:id
Public. Response: `{ song }`

### GET /songs/:id/stream
Public. Streams the audio file with HTTP `Range` support (206 partial content) for the `<audio>` element to seek. Also increments the song's play count.

### POST /songs
Admin only. `multipart/form-data` fields:
- `audio` (file, required — mp3/wav/ogg)
- `cover` (file, optional — jpg/png/webp)
- `title` (required), `artistId` (required), `albumId`, `genre`, `trackNumber`, `duration`
Response `201`: `{ song }`

### PUT /songs/:id
Admin only. Body: any of `{ title, artistId, albumId, genre, trackNumber }`. Response: `{ song }`

### DELETE /songs/:id
Admin only. Deletes the DB row and the underlying audio file.

---

## Artists

### GET /artists — Public. `{ artists: [...] }`
### GET /artists/search?q= — Public. `{ artists: [...] }`
### GET /artists/:id — Public. `{ artist }` including `Albums` and `Songs`.
### POST /artists — Admin only. `multipart/form-data`: `name` (required), `bio`, `genre`, `image` (file, optional).
### PUT /artists/:id — Admin only. Same fields, all optional.
### DELETE /artists/:id — Admin only. Blocked (400) if the artist still has songs.

---

## Albums

### GET /albums — Public. `{ albums: [...] }`
### GET /albums/search?q= — Public. `{ albums: [...] }`
### GET /albums/:id — Public. `{ album }` including `Songs` ordered by track number.
### POST /albums — Admin only. `multipart/form-data`: `title`, `artistId` (required), `releaseYear`, `genre`, `cover` (file, optional).
### PUT /albums/:id — Admin only.
### DELETE /albums/:id — Admin only. Songs are kept and unlinked (not deleted).

---

## Playlists

### GET /playlists
Optional auth. Returns public playlists, plus the caller's own private ones if authenticated.

### GET /playlists/:id
Optional auth. `403` if the playlist is private and you're not the owner.

### POST /playlists
Auth required. Body: `{ name (required), description, isPublic }`

### PUT /playlists/:id
Auth required, owner or admin only. Body: any of `{ name, description, isPublic }`. Also accepts `multipart/form-data` with a `cover` file.

### DELETE /playlists/:id
Auth required, owner or admin only.

### POST /playlists/:id/songs
Auth required, owner or admin only. Body: `{ songId }`. Appends to the end.

### DELETE /playlists/:id/songs/:songId
Auth required, owner or admin only. Re-sequences remaining positions.

### PATCH /playlists/:id/reorder
Auth required, owner or admin only. Body: `{ songIds: [ ...full ordered list of song IDs... ] }`

---

## Favorites

All routes below require auth.

### GET /favorites — `{ songs: [...] }` (most recently liked first)
### POST /favorites — Body: `{ songId }`
### DELETE /favorites/:songId

---

## History

All routes below require auth.

### GET /history/recent
De-duplicated list of the 20 most recently played songs (for the "Recently Played" shelf).

### GET /history/full?page=1&limit=30
Complete, non-deduplicated playback log, paginated.

### POST /history
Body: `{ songId }`. Logs a play event. The frontend calls this automatically whenever a track starts.

---

## Search (combined)

### GET /search?q=
Public. Runs a lightweight search across songs, artists, and albums in parallel.
Response: `{ songs: [...], artists: [...], albums: [...] }` (10 of each, max)

---

## Admin

All routes below require auth **and** an `admin` role.

### GET /admin/stats — `{ users, songs, playlists }`
### GET /admin/users — `{ users: [...] }` (password hashes excluded)
### PUT /admin/users/:id/role — Body: `{ role: "admin" | "user" }`
### DELETE /admin/users/:id — Cannot delete your own account while logged in as it.

---

## Error format

Non-2xx responses look like:

```json
{ "message": "Human-readable summary.", "details": ["optional", "field-level messages"] }
```

Common status codes: `400` validation, `401` missing/invalid token, `403` insufficient permission, `404` not found, `409` conflict (duplicate email/username, already-favorited, etc.), `500` unexpected server error.
